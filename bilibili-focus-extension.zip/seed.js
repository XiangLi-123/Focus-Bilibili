/* 测试用：写入示例白名单（MV3 不允许内联脚本，所以单独成文件） */
const SEED = {
  version: 1,
  enabled: true,
  pausedUntil: 0,
  settings: {
    blockNav: true, blockHot: true, blockRelated: true, blockComments: true,
    blockSearchReco: true, blockDynamic: true, blockHomeFeed: true, showBadge: true,
  },
  videos: [
    { bvid: 'BV1GJ411x7h7', aid: 170001, title: 'test-video-A', upName: 'testUP', upMid: 111, addedAt: Date.now() },
    { bvid: 'BV1xx411c7mD', aid: 170002, title: 'test-video-B', upName: 'testUP2', upMid: 222, addedAt: Date.now() },
  ],
  uploaders: [{ mid: 333, name: 'allowedUP', addedAt: Date.now() }],
};

const params = new URLSearchParams(location.search);
const config = JSON.parse(JSON.stringify(SEED));
if (params.get('empty') === '1') {
  config.videos = [];
  config.uploaders = [];
}

chrome.storage.local
  .set({ focusConfig: config })
  .then(() => {
    const out = document.getElementById('out');
    if (out) out.textContent = 'seeded ok: videos=' + config.videos.length + ' uploaders=' + config.uploaders.length;
  })
  .catch((error) => {
    const out = document.getElementById('out');
    if (out) out.textContent = 'seed failed: ' + error;
  });

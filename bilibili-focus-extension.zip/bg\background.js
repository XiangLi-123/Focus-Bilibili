/**
 * B 站专注模式 · Service Worker
 * 白名单的增删改只从这里写，保证 storage 只有一条写入路径。
 */
import { readConfig, updateConfig, isActive, writeConfig } from '../core/storage.js';
import { parseVideoRef, isBvid } from '../core/match.js';

const BADGE_BG = '#FB7299';

/* ------------------------------------------------------------------ */
/* 写队列：并发请求串行化，避免读改写丢数据                              */
/* ------------------------------------------------------------------ */

let queue = Promise.resolve();
function serial(task) {
  const run = queue.then(task, task);
  queue = run.catch(() => {});
  return run;
}

/* ------------------------------------------------------------------ */
/* 补全视频信息（拿 aid / upMid / 标题；失败也不阻塞主流程）             */
/* ------------------------------------------------------------------ */

async function fetchJson(url, timeoutMs = 4000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { credentials: 'include', signal: controller.signal });
    return await response.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchVideoMeta(bvid) {
  if (!isBvid(bvid)) return null;
  const json = await fetchJson(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`);
  if (!json || json.code !== 0 || !json.data) return null;
  const data = json.data;
  return {
    bvid: data.bvid || bvid,
    aid: Number(data.aid) || 0,
    cid: Number(data.cid) || 0,
    title: String(data.title || ''),
    upName: String(data.owner?.name || ''),
    upMid: Number(data.owner?.mid) || 0,
    cover: String(data.pic || ''),
    duration: Number(data.duration) || 0,
  };
}

async function fetchUploaderMeta(mid) {
  const json = await fetchJson(`https://api.bilibili.com/x/space/acc/info?mid=${mid}`, 3000);
  if (!json || json.code !== 0) return null;
  return { name: String(json.data?.name || ''), face: String(json.data?.face || '') };
}

function normalizeVideoInput(input) {
  if (!input || typeof input !== 'object') return null;
  const out = {
    bvid: isBvid(input.bvid) ? input.bvid : '',
    aid: Number(input.aid) > 0 ? Number(input.aid) : 0,
    cid: Number(input.cid) > 0 ? Number(input.cid) : 0,
    title: String(input.title || '').slice(0, 200),
    upName: String(input.upName || '').slice(0, 100),
    upMid: Number(input.upMid) > 0 ? Number(input.upMid) : 0,
    cover: String(input.cover || '').slice(0, 500),
    duration: Number(input.duration) > 0 ? Number(input.duration) : 0,
  };
  if (!out.bvid && !out.aid) return null;
  return out;
}

/* ------------------------------------------------------------------ */
/* 业务动作（全部返回写入后的完整 config）                              */
/* ------------------------------------------------------------------ */

async function addVideo(input, { allowFetch = true } = {}) {
  let video = normalizeVideoInput(input);
  if (!video) return { ok: false, error: '无效的视频信息' };

  if (allowFetch && video.bvid && (!video.aid || !video.upMid || !video.title)) {
    const meta = await fetchVideoMeta(video.bvid);
    if (meta) {
      video = {
        ...video,
        aid: video.aid || meta.aid,
        cid: video.cid || meta.cid,
        title: video.title || meta.title,
        upName: video.upName || meta.upName,
        upMid: video.upMid || meta.upMid,
        cover: video.cover || meta.cover,
        duration: video.duration || meta.duration,
      };
    }
  }

  let action = 'added';
  const config = await updateConfig((current) => {
    const exists = current.videos.find(
      (item) => (video.bvid && item.bvid === video.bvid) || (video.aid && Number(item.aid) === video.aid)
    );
    if (exists) {
      action = 'exists';
      exists.title = exists.title || video.title;
      exists.upName = exists.upName || video.upName;
      exists.upMid = exists.upMid || video.upMid;
      exists.cid = exists.cid || video.cid;
      exists.aid = exists.aid || video.aid;
      return current;
    }
    current.videos.unshift({ ...video, addedAt: Date.now() });
    return current;
  });

  return { ok: true, action, video, config };
}

async function toggleVideo(input) {
  const video = normalizeVideoInput(input);
  if (!video) return { ok: false, error: '无效的视频信息' };

  const current = await readConfig();
  const exists = current.videos.find(
    (item) => (video.bvid && item.bvid === video.bvid) || (video.aid && Number(item.aid) === video.aid)
  );
  if (exists) {
    const config = await updateConfig((cfg) => {
      cfg.videos = cfg.videos.filter((item) => {
        if (video.bvid && item.bvid === video.bvid) return false;
        if (video.aid && Number(item.aid) === video.aid) return false;
        return true;
      });
      return cfg;
    });
    return { ok: true, action: 'removed', config };
  }
  const result = await addVideo(video);
  return { ...result, action: 'added' };
}

async function addUploader(input) {
  const mid = Number(input?.mid);
  if (!Number.isFinite(mid) || mid <= 0) return { ok: false, error: '无效的 UP 主 mid' };
  let name = String(input?.name || '');
  let face = String(input?.face || '');
  if (!name) {
    const meta = await fetchUploaderMeta(mid);
    if (meta) {
      name = meta.name;
      face = face || meta.face;
    }
  }
  const config = await updateConfig((current) => {
    if (!current.uploaders.some((item) => item.mid === mid)) {
      current.uploaders.unshift({ mid, name, face, addedAt: Date.now() });
    }
    return current;
  });
  return { ok: true, config };
}

async function addFromUrl(url) {
  const ref = parseVideoRef(url);
  if (!ref) return { ok: false, error: '这个页面不是视频页，贴一个视频链接或 BV 号试试' };
  const meta = ref.bvid ? await fetchVideoMeta(ref.bvid) : null;
  const video = meta || { bvid: ref.bvid || '', aid: ref.aid || 0 };
  return addVideo(video, { allowFetch: false });
}

/* ------------------------------------------------------------------ */
/* 徽标                                                                 */
/* ------------------------------------------------------------------ */

async function refreshBadge(tabId) {
  if (!tabId) return;
  const config = await readConfig();
  if (!config.settings.showBadge || !isActive(config)) {
    await chrome.action.setBadgeText({ tabId, text: '' });
    return;
  }
  await chrome.action.setBadgeText({ tabId, text: String(config.videos.length) });
}

/* ------------------------------------------------------------------ */
/* 消息分发                                                             */
/* ------------------------------------------------------------------ */

async function handleMessage(message, sender) {
  const type = message?.type;
  const tabId = sender?.tab?.id;

  switch (type) {
    case 'getState':
      return { ok: true, config: await readConfig() };

    case 'toggleVideo': {
      const result = await serial(() => toggleVideo(message.video));
      if (result.ok) await refreshBadge(tabId);
      return result;
    }

    case 'addVideo': {
      const result = await serial(() => addVideo(message.video));
      if (result.ok) await refreshBadge(tabId);
      return result;
    }

    case 'removeVideo': {
      const config = await serial(() =>
        updateConfig((current) => {
          const target = message.video || {};
          current.videos = current.videos.filter((item) => {
            if (target.bvid && item.bvid === target.bvid) return false;
            if (target.aid && Number(item.aid) === Number(target.aid)) return false;
            return true;
          });
          return current;
        })
      );
      await refreshBadge(tabId);
      return { ok: true, config };
    }

    case 'addUploader':
      return serial(() => addUploader(message.uploader || {}));

    case 'removeUploader': {
      const mid = Number(message.mid);
      const config = await serial(() =>
        updateConfig((current) => {
          current.uploaders = current.uploaders.filter((item) => item.mid !== mid);
          return current;
        })
      );
      return { ok: true, config };
    }

    case 'setSettings': {
      const config = await serial(() =>
        updateConfig((current) => {
          for (const [key, value] of Object.entries(message.settings || {})) {
            if (typeof value === 'boolean') current.settings[key] = value;
          }
          return current;
        })
      );
      return { ok: true, config };
    }

    case 'setEnabled': {
      const config = await serial(() =>
        updateConfig((current) => {
          current.enabled = Boolean(message.enabled);
          if (!current.enabled) current.pausedUntil = 0;
          return current;
        })
      );
      return { ok: true, config };
    }

    case 'setPass': {
      const minutes = Number(message.minutes);
      const config = await serial(() =>
        updateConfig((current) => {
          current.pausedUntil =
            Number.isFinite(minutes) && minutes > 0 ? Date.now() + minutes * 60 * 1000 : 0;
          return current;
        })
      );
      return { ok: true, config };
    }

    case 'importConfig': {
      const payload = message.payload || {};
      const config = await serial(() =>
        updateConfig((current) => {
          if (Array.isArray(payload.videos)) current.videos = payload.videos;
          if (Array.isArray(payload.uploaders)) current.uploaders = payload.uploaders;
          if (payload.settings && typeof payload.settings === 'object') {
            current.settings = { ...current.settings, ...payload.settings };
          }
          return current;
        })
      );
      return { ok: true, config };
    }

    case 'addFromUrl':
      return serial(() => addFromUrl(message.url));

    case 'badge': {
      const count = Number(message.count);
      if (tabId && Number.isFinite(count)) {
        await chrome.action.setBadgeText({ tabId, text: String(count) });
      }
      return { ok: true };
    }

    case 'openOptions':
      await chrome.runtime.openOptionsPage();
      return { ok: true };

    default:
      return { ok: false, error: `未知消息：${type}` };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then((result) => sendResponse(result ?? { ok: true }))
    .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true; // 异步响应
});

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get('focusConfig');
  if (!stored.focusConfig) await writeConfig({});
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_BG }).catch(() => {});
});

chrome.action.setBadgeBackgroundColor({ color: BADGE_BG }).catch(() => {});

chrome.tabs.onActivated.addListener(({ tabId }) => {
  refreshBadge(tabId).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});
  }
});

/* 跳转到管理大窗口（options 页只做重定向，界面与弹窗共用） */
location.replace(chrome.runtime.getURL('popup/popup.html?view=full'));

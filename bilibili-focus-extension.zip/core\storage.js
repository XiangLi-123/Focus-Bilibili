/**
 * B 站专注模式 · 数据层
 * 所有页面（content / popup / background）共用同一份 chrome.storage.local 配置。
 */

export const STORAGE_KEY = 'focusConfig';

/** 屏蔽项开关。true = 隐藏 */
export const DEFAULT_SETTINGS = {
  blockNav: true,          // 顶部导航的 首页 / 热门 / 动态 入口
  blockHot: true,          // 热搜、热榜、排行榜入口
  blockRelated: true,      // 视频页右侧「相关推荐」整栏
  blockComments: true,     // 评论区
  blockSearchReco: true,   // 搜索页顶部的「搜索发现 / 相关搜索」
  blockDynamic: true,      // 动态页时间线
  blockHomeFeed: true,     // 首页信息流
  showBadge: true,         // 扩展图标上显示已屏蔽数量
};

export const DEFAULT_CONFIG = {
  version: 1,
  enabled: true,
  pausedUntil: 0,
  settings: { ...DEFAULT_SETTINGS },
  /** [{ bvid, aid, cid, title, upName, upMid, cover, duration, addedAt }] */
  videos: [],
  /** [{ mid, name, face, addedAt }] */
  uploaders: [],
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeEntry(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const out = {};
  if (typeof entry.bvid === 'string' && /^BV[0-9A-Za-z]{10}$/.test(entry.bvid)) {
    out.bvid = entry.bvid;
  }
  if (Number.isFinite(Number(entry.aid)) && Number(entry.aid) > 0) out.aid = Number(entry.aid);
  if (Number.isFinite(Number(entry.cid)) && Number(entry.cid) > 0) out.cid = Number(entry.cid);
  if (!out.bvid && !out.aid) return null;
  out.title = String(entry.title || '').slice(0, 200);
  out.upName = String(entry.upName || '').slice(0, 100);
  out.upMid = Number.isFinite(Number(entry.upMid)) && Number(entry.upMid) > 0 ? Number(entry.upMid) : 0;
  out.cover = String(entry.cover || '').slice(0, 500);
  out.duration = Number.isFinite(Number(entry.duration)) ? Number(entry.duration) : 0;
  out.addedAt = Number.isFinite(Number(entry.addedAt)) ? Number(entry.addedAt) : Date.now();
  return out;
}

function normalizeUploader(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const mid = Number(entry.mid);
  if (!Number.isFinite(mid) || mid <= 0) return null;
  return {
    mid,
    name: String(entry.name || '').slice(0, 100),
    face: String(entry.face || '').slice(0, 500),
    addedAt: Number.isFinite(Number(entry.addedAt)) ? Number(entry.addedAt) : Date.now(),
  };
}

/** 把任意（可能损坏的）读入数据规范成完整配置 */
export function normalizeConfig(raw) {
  const base = clone(DEFAULT_CONFIG);
  if (!raw || typeof raw !== 'object') return base;

  if (raw.enabled === false) base.enabled = false;
  const pausedUntil = Number(raw.pausedUntil);
  if (Number.isFinite(pausedUntil) && pausedUntil > 0) base.pausedUntil = pausedUntil;

  if (raw.settings && typeof raw.settings === 'object') {
    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      if (typeof raw.settings[key] === 'boolean') base.settings[key] = raw.settings[key];
    }
  }

  if (Array.isArray(raw.videos)) {
    const seen = new Set();
    for (const item of raw.videos) {
      const entry = normalizeEntry(item);
      if (!entry) continue;
      const key = entry.bvid || `av${entry.aid}`;
      if (seen.has(key)) continue;
      seen.add(key);
      base.videos.push(entry);
    }
  }

  if (Array.isArray(raw.uploaders)) {
    const seen = new Set();
    for (const item of raw.uploaders) {
      const entry = normalizeUploader(item);
      if (!entry || seen.has(entry.mid)) continue;
      seen.add(entry.mid);
      base.uploaders.push(entry);
    }
  }

  return base;
}

export async function readConfig() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return normalizeConfig(stored[STORAGE_KEY]);
}

export async function writeConfig(config) {
  const normalized = normalizeConfig(config);
  await chrome.storage.local.set({ [STORAGE_KEY]: normalized });
  return normalized;
}

/** 读 → 改 → 写，保证并发安全（Service Worker 单线程，消息天然串行） */
export async function updateConfig(mutator) {
  const current = await readConfig();
  const next = (await mutator(current)) || current;
  return writeConfig(next);
}

export function onConfigChanged(callback) {
  const listener = (changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY]) return;
    callback(normalizeConfig(changes[STORAGE_KEY].newValue));
  };
  chrome.storage.onChanged.addListener(listener);
  return () => chrome.storage.onChanged.removeListener(listener);
}

/** 当前是否处于「生效中」（启用且未临时放行） */
export function isActive(config, now = Date.now()) {
  return Boolean(config && config.enabled && !(config.pausedUntil > now));
}

/** 临时放行剩余秒数，0 表示没有放行 */
export function passRemainingSeconds(config, now = Date.now()) {
  if (!config || !(config.pausedUntil > now)) return 0;
  return Math.ceil((config.pausedUntil - now) / 1000);
}

/* B 站专注模式 · page-hook（由 build.mjs 从 src/ 生成，请勿直接改这个文件） */
(() => {
'use strict';

/* ---- core/match.js ---- */
/**
 * B 站专注模式 · 白名单匹配
 * 纯逻辑，不依赖 DOM，可在页面 / Service Worker / Node 测试中复用。
 */

const BV_RE = /^BV[0-9A-Za-z]{10}$/;
function isBvid(value) {
  return typeof value === 'string' && BV_RE.test(value.trim());
}

/** 从任意字符串/URL 中提取 bvid 与 aid */
function parseVideoRef(input) {
  const text = String(input || '').trim();
  if (!text) return null;

  const bvMatch = text.match(/BV[0-9A-Za-z]{10}/);
  const avMatch = text.match(/av(\d+)/i);
  const result = {};
  if (bvMatch) result.bvid = bvMatch[0];
  if (avMatch) result.aid = Number(avMatch[1]);

  // 纯数字也当成 aid（用户直接粘贴 aid 的情况）
  if (!result.bvid && !result.aid && /^\d{1,12}$/.test(text)) result.aid = Number(text);
  if (!result.bvid && !result.aid) return null;
  return result;
}
function videoKey(entry) {
  if (!entry) return '';
  if (entry.bvid) return entry.bvid;
  if (entry.aid) return `av${entry.aid}`;
  return '';
}

/** 用于识别「这个条目是不是白名单里的视频」的 id 集合 */
class Matcher {
  constructor(config) {
    this.config = config || { videos: [], uploaders: [] };
    this.bvids = new Set();
    this.aids = new Set();
    this.mids = new Set();
    this.titleTokens = new Set();

    for (const video of this.config.videos || []) {
      if (video.bvid) this.bvids.add(video.bvid);
      if (video.aid) this.aids.add(String(video.aid));
    }
    for (const up of this.config.uploaders || []) {
      if (up.mid) this.mids.add(String(up.mid));
    }
  }

  get empty() {
    return this.bvids.size === 0 && this.aids.size === 0 && this.mids.size === 0;
  }

  get total() {
    return this.bvids.size + this.mids.size;
  }

  /** 视频是否被放行（bvid 或 aid 命中，或 UP 主被放行） */
  allowsVideo(bvid, aid, upMid) {
    if (bvid && this.bvids.has(bvid)) return true;
    if (aid && this.aids.has(String(aid))) return true;
    if (upMid && this.mids.has(String(upMid))) return true;
    return false;
  }

  /** 条目本身带的身份信息 */
  allowsEntry(entry) {
    if (!entry) return false;
    return this.allowsVideo(entry.bvid, entry.aid, entry.upMid ?? entry.mid);
  }

  allowsUploader(mid) {
    return Boolean(mid) && this.mids.has(String(mid));
  }

  hasBvid(bvid) {
    return Boolean(bvid) && this.bvids.has(bvid);
  }

  hasAid(aid) {
    return Boolean(aid) && this.aids.has(String(aid));
  }

  hasUploader(mid) {
    return this.allowsUploader(mid);
  }
}
function createMatcher(config) {
  return new Matcher(config);
}

/**
 * 从 B 站各种接口的 item 里尽力抽取身份：
 * 视频卡片 / 动态卡片 / 搜索结果 / 相关推荐 都能覆盖。
 */
function extractVideoIds(item) {
  if (!item || typeof item !== 'object') return {};

  const out = {};
  const push = (candidate) => {
    if (!candidate) return;
    if (!out.bvid && isBvid(candidate)) out.bvid = candidate.trim();
    else if (!out.aid && typeof candidate === 'number' && Number.isFinite(candidate) && candidate > 0) {
      out.aid = candidate;
    }
  };

  // 结构比较深的候选字段
  const direct = [
    item.bvid,
    item.bv_id,
    item.id,
    item.aid,
    item.avid,
    item.archive?.bvid,
    item.archive?.aid,
    item.args?.bvid,
    item.args?.aid,
    item.reserve?.bvid,
  ];
  for (const value of direct) push(value);

  const args = item.args;
  if (args && typeof args === 'object') {
    if (typeof args.bvid === 'string') push(args.bvid);
    if (typeof args.aid === 'string' && /^\d+$/.test(args.aid)) push(Number(args.aid));
  }

  // 动态卡片
  const major = item.modules?.module_dynamic?.major;
  if (major?.archive?.bvid) push(major.archive.bvid);
  if (major?.archive?.aid) push(major.archive.aid);
  if (major?.archive?.id) push(major.archive.id);
  if (major?.pgc?.jump_url) push(major.pgc.jump_url);

  // 搜索结果里 href 形如 //www.bilibili.com/video/BVxxx
  for (const key of ['arcurl', 'jump_url', 'uri', 'url']) {
    const value = item[key];
    if (typeof value !== 'string') continue;
    const parsed = parseVideoRef(value);
    if (parsed) {
      if (!out.bvid && parsed.bvid) out.bvid = parsed.bvid;
      if (!out.aid && parsed.aid) out.aid = parsed.aid;
    }
  }

  // 兜底：链接里直接带 BV 号
  for (const key of ['link', 'href', 'share_url']) {
    if (typeof item[key] === 'string' && isBvid(item[key])) push(item[key]);
  }

  return out;
}
function extractUpMid(item) {
  if (!item || typeof item !== 'object') return 0;
  const candidates = [
    item.upMid,
    item.owner?.mid,
    item.author?.mid,
    item.up?.mid,
    item.modules?.module_author?.mid,
    item.mid,
  ];
  for (const value of candidates) {
    const mid = Number(value);
    if (Number.isFinite(mid) && mid > 0) return mid;
  }
  // 搜索结果里有时是 "author" 字符串 + "mid"，或者跳转链接里的 space/数字
  for (const key of ['jump_url', 'uri', 'arcurl']) {
    const value = item[key];
    if (typeof value !== 'string') continue;
    const match = value.match(/space\.bilibili\.com\/(\d+)/);
    if (match) return Number(match[1]);
  }
  return 0;
}

/** 是否是「视频类」卡片（非视频类：广告、番剧、直播、课程等） */
function isVideoLike(item) {
  if (!item || typeof item !== 'object') return false;
  const goto = String(item.goto || item.card_goto || item.type || '');
  if (goto === 'av' || goto === 'video' || goto === 'archive' || goto === 'ogv') return true;
  if (goto && ['live', 'article', 'pgc', 'bangumi', 'ad', 'special', 'dynamic'].includes(goto)) return false;
  if (typeof item.bvid === 'string' && isBvid(item.bvid)) return true;
  if (item.owner && item.owner.mid) return true;
  if (item.modules?.module_dynamic?.major?.archive) return true;
  return false;
}

/**
 * 视频页 URL 解析：返回 { bvid, p }
 * 注意：这是纯字符串解析，不是 URL API（兼容 Service Worker / Node）
 */
function parseVideoPageUrl(href) {
  const text = String(href || '');
  const match = text.match(/\/video\/(BV[0-9A-Za-z]{10})/);
  if (!match) return null;
  const pageMatch = text.match(/[?&]p=(\d+)/);
  return { bvid: match[1], p: pageMatch ? Number(pageMatch[1]) : 1 };
}

/* ---- core/api.js ---- */
/**
 * B 站专注模式 · 接口过滤
 *
 * B 站前端是 SPA，卡片来自后台接口。与其和 DOM 打架，
 * 不如在接口返回时直接把「不在白名单里的卡片」从 JSON 里削掉：
 * 页面拿到的数据本身只剩你要看的视频，连滚动加载都干净。
 *
 * 不依赖 DOM / chrome API，可在 Node 里直接测。
 */

/** 需要接管的接口（命中就过滤，其余一律放行） */
const RULES = [
  { id: 'home', path: /\/x\/web-interface\/(?:wbi\/)?index\/top\/feed\/rcmd/, policy: 'feed' },
  { id: 'home-feed', path: /\/x\/web-interface\/(?:wbi\/)?index\/top\/feed\//, policy: 'feed' },
  { id: 'related', path: /\/x\/web-interface\/(?:wbi\/)?archive\/(?:related|relation)/, policy: 'drop' },
  { id: 'search', path: /\/x\/web-interface\/(?:wbi\/)?search\/(?:type|all\/v2)/, policy: 'search' },
  { id: 'dynamic', path: /\/x\/polymer\/web-dynamic\/v1\/feed\/all/, policy: 'drop' },
  { id: 'popular', path: /\/x\/web-interface\/(?:wbi\/)?popular(?:\/|$|\?)/, policy: 'feed' },
  { id: 'ranking', path: /\/x\/web-interface\/(?:wbi\/)?ranking\/v2/, policy: 'feed' },
  { id: 'live', path: /\/xlive\/web-interface\/v1\/get_(?:recommend|list_by_area)/, policy: 'feed' },
];
function classifyEndpoint(url) {
  if (!url) return null;
  const text = String(url);
  if (!/bilibili\.com|biliapi/.test(text)) return null;
  for (const rule of RULES) {
    if (rule.path.test(text)) return rule;
  }
  return null;
}
function shouldIntercept(url) {
  return Boolean(classifyEndpoint(url));
}

const LIST_KEYS = ['item', 'items', 'list', 'archives', 'videos', 'result'];

function noteBlocked(stats, ids) {
  stats.blocked += 1;
  if (ids.bvid) stats.seen.add(ids.bvid);
  else if (ids.aid) stats.seen.add(`av${ids.aid}`);
}

/** 过滤数组里的卡片，返回删除数量 */
/** 明确的「非视频」内容类型：小广告、直播、番剧、专栏等 */
const NON_VIDEO_GOTO = new Set(['ad', 'live', 'pgc', 'bangumi', 'article', 'special', 'course', 'ogv']);

/**
 * 过滤数组里的卡片。
 * 策略（白名单模式的严格版）：feed / 搜索 / 动态里，凡是不在白名单中的卡片一律删除，
 * 包括认不出 BV 号的广告、直播、番剧等推荐位。
 * 唯一例外是页面渲染必需的「配置占位」对象（没有 goto / bvid / owner 的纯数据对象）。
 */
function filterArray(arr, matcher, stats) {
  if (!Array.isArray(arr)) return 0;
  let removed = 0;
  for (let i = arr.length - 1; i >= 0; i -= 1) {
    const item = arr[i];
    if (!item || typeof item !== 'object') continue;

    const ids = extractVideoIds(item);
    const upMid = extractUpMid(item);
    if (matcher.allowsVideo(ids.bvid, ids.aid, upMid)) continue;

    const goto = String(item.goto || item.card_goto || item.type || '').toLowerCase();
    const looksLikeCard =
      Boolean(ids.bvid || ids.aid) ||
      Boolean(item.owner || item.card_goto || item.modules || item.args) ||
      [...NON_VIDEO_GOTO].some((type) => goto.includes(type));

    if (!looksLikeCard) continue; // 纯配置对象 / 占位字段，不能动

    arr.splice(i, 1);
    removed += 1;
    noteBlocked(stats, ids);
  }
  return removed;
}

/** 搜索接口：保持 result_type，只过滤 video 桶 */
function filterSearchResult(result, matcher, stats) {
  if (!result || typeof result !== 'object') return 0;
  let removed = 0;
  for (const key of Object.keys(result)) {
    const bucket = result[key];
    if (!Array.isArray(bucket) || bucket.length === 0) continue;
    const type = String(bucket[0]?.result_type || key);
    if (type !== 'video' && key !== 'video') continue;
    removed += filterArray(bucket, matcher, stats);
  }
  return removed;
}

/** 递归找视频数组并过滤（首页 feed、相关推荐、热门、动态都能覆盖） */
function filterPayload(node, matcher, stats, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 6) return 0;
  if (Array.isArray(node)) return filterArray(node, matcher, stats);

  let removed = 0;
  for (const key of Object.keys(node)) {
    const child = node[key];
    if (Array.isArray(child)) {
      if (child.some((item) => item && typeof item === 'object' && (item.bvid || item.card_goto || item.owner || item.modules))) {
        removed += filterArray(child, matcher, stats);
      }
    } else if (child && typeof child === 'object') {
      removed += filterPayload(child, matcher, stats, depth + 1);
    }
  }
  return removed;
}

/**
 * 主入口：就地修改 json 里的卡片列表。
 * @returns {{applied:boolean, removed:number, ids:string[]}}
 */
function filterApiJson(url, json, matcher) {
  const rule = classifyEndpoint(url);
  if (!rule || !json || typeof json !== 'object') {
    return { applied: false, removed: 0, ids: [] };
  }
  if (json.code !== undefined && Number(json.code) !== 0) {
    return { applied: false, removed: 0, ids: [] };
  }

  const stats = { blocked: 0, seen: new Set() };
  if (rule.policy === 'search') {
    filterSearchResult(json.data?.result || json.result, matcher, stats);
  } else {
    filterPayload(json, matcher, stats);
  }

  return { applied: true, removed: stats.blocked, ids: [...stats.seen] };
}

/* ---- page/page-hook.js ---- */
/**
 * B 站专注模式 · 页面注入脚本（MAIN world）
 *
 * 运行在 B 站页面自己的 JS 环境里，所以能：
 *   1. 在 B 站前端拿到数据之前，把接口 JSON 里非白名单的卡片删掉；
 *   2. 兜底处理服务端直出的卡片 / 静态页面里的推荐位。
 *
 * 与扩展通信只靠 window.__BF__ 上的配置对象 + 自定义事件，不碰页面自己的变量。
 */

const EVT_READY = 'bf:ready';
const EVT_CONFIG = 'bf:config';
const EVT_VIDEO_INFO = 'bf:video-info';
const EVT_BLOCKED = 'bf:blocked';
/** 隔离环境 → 页面世界单向通道（CustomEvent.detail 会跨世界结构化克隆） */
const EVT_SET_CONFIG = 'bf:set-config';
const EVT_REQUEST = 'bf:request';

const state = {
  config: null,
  matcher: createMatcher(null),
  active: false,
  blockedIds: new Set(),
  reported: 0,
  scanTimer: 0,
  feedEmpty: null,
  emptyTimer: 0,
  sawFiltered: false,
};

/** 轻量运行状态：写在 <html data-bf-stat> 上，方便用户/我们排查「今天为什么是空的」 */
const stats = { filtered: 0, cards: '' };
function publishStats() {
  try {
    document.documentElement?.setAttribute(
      'data-bf-stat',
      `filtered=${stats.filtered};cards=${stats.cards || '-'}`
    );
  } catch {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ */
/* 与隔离环境通信                                                       */
/* 注意：world: MAIN 的脚本和 content script 是两个独立的 JS 世界，       */
/* window 上的对象互相看不见，所以配置和数据全部走 DOM 事件传递。          */
/* ------------------------------------------------------------------ */

function applyConfig(config) {
  state.config = config && typeof config === 'object' ? config : null;
  state.matcher = createMatcher(state.config);
  const now = Date.now();
  state.active = Boolean(state.config && state.config.enabled && !(state.config.pausedUntil > now));
  document.documentElement?.setAttribute('data-bf-active', state.active ? '1' : '');
  dispatch(EVT_CONFIG, { active: state.active, total: state.matcher.total });
  scheduleScan();
  return { active: state.active, total: state.matcher.total };
}

/** 配置由隔离环境通过 document 上的 CustomEvent 送进来（两个世界共享 DOM） */
document.addEventListener(EVT_SET_CONFIG, (event) => {
  applyConfig(event.detail);
});

/** content script 主动敲门时，回一条 bf:ready 让它知道我们已经就绪 */
document.addEventListener(EVT_REQUEST, () => {
  dispatch(EVT_READY, { version: 1, total: state.matcher.total });
});

/** 站内路由变化后重新上报视频信息（悬浮按钮状态） */
document.addEventListener('bf:report', () => {
  reportVideoInfo();
});

function dispatch(name, detail) {
  try {
    window.dispatchEvent(new CustomEvent(name, { detail, bubbles: true }));
  } catch {
    /* 页面里极端情况下 dispatch 失败，忽略 */
  }
}

function flushBlocked() {
  if (state.blockedIds.size === state.reported) return;
  state.reported = state.blockedIds.size;
  dispatch(EVT_BLOCKED, { count: state.reported, ids: [...state.blockedIds].slice(0, 50) });
}

function reportBlockedIds(ids) {
  if (!ids || typeof ids[Symbol.iterator] !== 'function') return;
  for (const id of ids) state.blockedIds.add(id);
  flushBlocked();
}

/* ------------------------------------------------------------------ */
/* 1. fetch 拦截                                                        */
/* ------------------------------------------------------------------ */

const nativeFetch = window.fetch;
if (typeof nativeFetch === 'function' && !nativeFetch.__bfPatched) {
  const patched = async function fetch(input, init) {
    const response = await nativeFetch.call(this, input, init);
    try {
      const url = typeof input === 'string' ? input : input?.url || '';
      if (!state.active || !shouldIntercept(url) || !response.ok) return response;

      let text;
      try {
        text = await response.clone().text();
      } catch {
        return response;
      }
      if (!text || text.length > 6 * 1024 * 1024) return response;

      let json;
      try {
        json = JSON.parse(text);
      } catch {
        return response;
      }

      let result;
      try {
        result = filterApiJson(url, json, state.matcher);
      } catch {
        return response;
      }
      // 这一路接口被真的处理过 = 推荐流在跑，占位卡片可以安全收起
      state.sawFiltered = true;
      if (!result.applied) return response;
      if (result.removed > 0) {
        stats.filtered += result.removed;
        reportBlockedIds(result.ids);
      }
      publishStats();

      const headers = new Headers(response.headers);
      headers.delete('content-length');
      headers.delete('content-encoding');
      headers.set('content-type', 'application/json; charset=utf-8');
      const body = JSON.stringify(json);
      headers.set('content-length', String(new TextEncoder().encode(body).length));
      return new Response(body, {
        status: response.status,
        statusText: response.statusText,
        headers,
      });
    } catch {
      return response;
    }
  };
  patched.__bfPatched = true;
  window.fetch = patched;
}

/* ------------------------------------------------------------------ */
/* 2. XHR 拦截                                                          */
/* ------------------------------------------------------------------ */

const NativeXHR = window.XMLHttpRequest;
if (NativeXHR && !NativeXHR.prototype.__bfPatched) {
  const nativeOpen = NativeXHR.prototype.open;
  const nativeSend = NativeXHR.prototype.send;
  const nativeResponseText = Object.getOwnPropertyDescriptor(NativeXHR.prototype, 'responseText');
  const nativeResponse = Object.getOwnPropertyDescriptor(NativeXHR.prototype, 'response');

  NativeXHR.prototype.open = function open(method, url, ...rest) {
    try {
      this.__bfUrl = typeof url === 'string' ? url : String(url);
    } catch {
      this.__bfUrl = '';
    }
    return nativeOpen.call(this, method, url, ...rest);
  };

  NativeXHR.prototype.send = function send(...args) {
    if (state.active && shouldIntercept(this.__bfUrl)) {
      if (!this.__bfHooked) {
        this.__bfHooked = true;
        this.addEventListener('readystatechange', () => {
          if (this.readyState !== 4 || this.__bfFiltered) return;
          this.__bfFiltered = true;
          try {
            applyXhrFilter(this);
          } catch {
            /* 过滤失败就保留原始响应 */
          }
        });
      }
    }
    return nativeSend.apply(this, args);
  };

  function applyXhrFilter(xhr) {
    const raw = nativeResponseText?.get?.call(xhr);
    if (typeof raw !== 'string' || raw.length > 6 * 1024 * 1024) return;
    let json;
    try {
      json = JSON.parse(raw);
    } catch {
      return;
    }
    const result = filterApiJson(xhr.__bfUrl, json, state.matcher);
    state.sawFiltered = true;
    if (!result.applied) return;
    if (result.removed > 0) {
      stats.filtered += result.removed;
      reportBlockedIds(result.ids);
    }
    publishStats();

    const body = JSON.stringify(json);
    Object.defineProperty(xhr, 'responseText', {
      configurable: true,
      get: () => body,
    });
    if (nativeResponse?.get) {
      Object.defineProperty(xhr, 'response', {
        configurable: true,
        get: () => (xhr.responseType === 'json' ? JSON.parse(body) : body),
      });
    }
  }

  NativeXHR.prototype.__bfPatched = true;
}

/* ------------------------------------------------------------------ */
/* 3. DOM 兜底：删掉页面上残留的非白名单卡片                            */
/* ------------------------------------------------------------------ */

/** 卡片内链接 → 白名单判定 */
function cardAllowed(card) {
  if (!card || card.nodeType !== 1) return true;
  const anchors = card.querySelectorAll('a[href*="/video/"]');
  if (!anchors.length) return true;

  const upMid = Number(card.getAttribute('data-mmid') || 0);
  if (upMid && state.matcher.allowsUploader(upMid)) return true;

  let sawVideo = false;
  for (const anchor of anchors) {
    const parsed = parseVideoPageUrl(anchor.getAttribute('href') || '');
    if (!parsed) continue;
    sawVideo = true;
    if (state.matcher.hasBvid(parsed.bvid)) return true;
  }
  return !sawVideo;
}

const CARD_SELECTORS = [
  '.bili-video-card',
  '.feed-card',
  '.floor-card',
  '.bili-dyn-item',
  '.video-page-card-small',
  '.video-page-card',
  '.search-page-video',
  '.rec-list .video-card-common',
  '.video-card-common',
  '.small-item',
  '.rank-item',
  '.video-card',
  '.bilibili-video-card',
  // 首页新版（V8 布局）的楼层卡片 / 轮播卡片
  '.floor-single-card',
  '.recommended-swipe-core',
  '.recommended-swipe-body',
  '.feed-card',
];

function hideCard(card) {
  if (!card || card.classList?.contains('bf-card-hidden')) return;
  card.classList.add('bf-card-hidden');
  card.setAttribute('aria-hidden', 'true');
  // 双保险：某些站点样式表用 !important 覆盖 display，这里直接写内联样式
  try {
    card.style.setProperty('display', 'none', 'important');
  } catch {
    /* ignore */
  }
}

/**
 * B 站首页首屏卡片由服务端直出（__INITIAL_STATE__），不经过接口，
 * 因此必须做 DOM 兜底：卡片里没有可识别视频链接的（骨架屏 / 广告位 / 占位）
 * 在「白名单模式」下一律隐藏；有链接但不在白名单里的也隐藏。
 */
/**
 * 通用兜底：任何「包含视频链接、但不在白名单里」的卡片，都往上折到
 * 「一行一张卡」的层级后隐藏。B 站改版后卡片类名经常变，这条兜底能接住。
 */
function scanVideoAnchors() {
  const anchors = document.querySelectorAll('a[href*="/video/BV"]');
  for (const anchor of anchors) {
    const ref = parseVideoPageUrl(anchor.getAttribute('href') || '');
    if (!ref || state.matcher.hasBvid(ref.bvid)) continue;

    // 往上找卡片：优先常见卡片类名，找不到就用「尺寸接近卡片」的祖先
    let node = anchor;
    let card = null;
    for (let i = 0; i < 8 && node; i += 1) {
      if (/bili-video-card|video-card|feed-card|floor-card|bili-dyn-item|search-page-video|small-item|video-page-card/.test(node.className || '')) {
        card = node;
        break;
      }
      node = node.parentElement;
    }
    if (!card) {
      node = anchor.parentElement;
      for (let i = 0; i < 6 && node; i += 1) {
        const rect = node.getBoundingClientRect();
        if (rect.width >= 140 && rect.height >= 90) {
          card = node;
          break;
        }
        node = node.parentElement;
      }
    }
    if (card) hideCard(card);
  }
}

function scanDom() {
  if (!state.active) return;
  const seen = new Set();
  let visibleCards = 0;
  let hiddenCards = 0;

  for (const selector of CARD_SELECTORS) {
    let nodes;
    try {
      nodes = document.querySelectorAll(selector);
    } catch {
      continue;
    }
    for (const card of nodes) {
      if (seen.has(card)) continue;
      seen.add(card);

      const allAnchors = card.querySelectorAll('a[href]');
      const videoAnchors = card.querySelectorAll('a[href*="/video/"]');

      if (!allAnchors.length) {
        // 纯占位/骨架卡片：只有在确认推荐流已经被过滤过之后才隐藏，
        // 否则会在正常加载阶段把真实卡片也提前吃掉（骨架和卡片是同一个类）。
        if (state.sawFiltered) {
          hideCard(card);
          hiddenCards += 1;
        }
        continue;
      }

      // 有链接但没有任何视频链接 → 课程 / 番剧 / 直播 / 专栏等非视频内容。
      // 白名单模式下只放行视频，这类一概收起（这就是「只看我选的视频」）。
      if (!videoAnchors.length) {
        hideCard(card);
        hiddenCards += 1;
        continue;
      }

      if (cardAllowed(card)) {
        visibleCards += 1;
      } else {
        hideCard(card);
        hiddenCards += 1;
      }
    }
  }

  // 兜底扫一遍所有视频链接（接住类名变动 / 未覆盖的卡片）
  scanVideoAnchors();

  stats.cards = `${visibleCards}/${visibleCards + hiddenCards}`;
  publishStats();
  reportFeedEmptiness(visibleCards);
}

/** 告诉隔离环境「首页已经没有可显示的视频了」，用来显示空状态卡片 */
function reportFeedEmptiness(visibleCards) {
  if (!state.active) return;
  const onHome = location.pathname === '/' || location.pathname === '';
  const hasWhitelist = !state.matcher.empty;
  const empty = onHome && hasWhitelist && visibleCards === 0;

  if (empty) {
    // 新页面可能只是还没渲染完，延迟确认一次；期间若出现真实卡片就取消
    if (state.emptyTimer) return;
    state.emptyTimer = window.setTimeout(() => {
      state.emptyTimer = 0;
      if (!state.active) return;
      // 重新数一遍，避免用旧结果
      const live = [...document.querySelectorAll('.bili-video-card, .feed-card, .floor-single-card')].filter(
        (card) => !card.classList.contains('bf-card-hidden') && getComputedStyle(card).display !== 'none'
      ).length;
      if (live > 0) return;
      if (state.feedEmpty === true) return;
      state.feedEmpty = true;
      dispatch('bf:feed-empty', { empty: true });
    }, 1200);
    return;
  }

  if (state.emptyTimer) {
    window.clearTimeout(state.emptyTimer);
    state.emptyTimer = 0;
  }
  if (state.feedEmpty !== false) {
    state.feedEmpty = false;
    dispatch('bf:feed-empty', { empty: false });
  }
}

function scheduleScan() {
  if (state.scanTimer) return;
  state.scanTimer = window.setTimeout(() => {
    state.scanTimer = 0;
    scanDom();
  }, 200);
}

const observer = new MutationObserver(() => scheduleScan());
if (document.documentElement) {
  observer.observe(document.documentElement, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  });
}

/* 单页应用换路由时重新扫一遍 */
for (const method of ['pushState', 'replaceState']) {
  const original = history[method];
  if (typeof original !== 'function' || original.__bfPatched) continue;
  const wrapped = function wrappedHistory(...args) {
    const ret = original.apply(this, args);
    scheduleScan();
    window.setTimeout(reportVideoInfo, 300);
    return ret;
  };
  wrapped.__bfPatched = true;
  history[method] = wrapped;
}
window.addEventListener('popstate', () => {
  scheduleScan();
  window.setTimeout(reportVideoInfo, 300);
});

/* B 站自己的路由可能直接操作 history，不一定会触发 popstate；
   用 URL 轮询兜底，保证站内换视频后悬浮按钮状态跟得上。 */
let lastHref = location.href;
window.setInterval(() => {
  if (location.href === lastHref) return;
  lastHref = location.href;
  scheduleScan();
  window.setTimeout(reportVideoInfo, 300);
}, 800);

/* ------------------------------------------------------------------ */
/* 4. 视频页信息上报（给悬浮按钮用）                                     */
/* ------------------------------------------------------------------ */

function pickVideoInfo() {
  const url = parseVideoPageUrl(location.href);
  if (!url) return null;

  const info = {
    bvid: url.bvid,
    aid: 0,
    cid: 0,
    title: '',
    upName: '',
    upMid: 0,
    cover: '',
    duration: 0,
    isVideoPage: true,
  };

  try {
    const init = window.__INITIAL_STATE__;
    const video = init?.videoData || init?.videoInfo || init?.video;
    if (video && typeof video === 'object') {
      // URL 里的 bvid 才是权威（站内换视频时 __INITIAL_STATE__ 可能是旧的），
      // 这里只在「两者一致」或 URL 解析不出时，才采用内嵌数据。
      const embedded = video.bvid || video.bv_id;
      const consistent = !isBvid(embedded) || embedded === info.bvid;
      if (consistent) {
        if (Number(video.aid) > 0) info.aid = Number(video.aid);
        if (Number(video.cid) > 0) info.cid = Number(video.cid);
        if (typeof video.title === 'string') info.title = video.title;
        const pages = Array.isArray(video.pages) ? video.pages : [];
        if (!info.cid && pages[0]?.cid) info.cid = Number(pages[0].cid);
        if (!info.duration && pages[0]?.duration) info.duration = Number(pages[0].duration);
        if (!info.duration && video.duration) info.duration = Number(video.duration);
      }
    }
    const up = init?.upData;
    if (up && typeof up === 'object') {
      if (up.name) info.upName = String(up.name);
      if (Number(up.mid) > 0) info.upMid = Number(up.mid);
    }
  } catch {
    /* __INITIAL_STATE__ 结构可能变，忽略 */
  }

  if (!info.title) {
    const heading = document.querySelector('h1.video-title, h1[title], .video-title');
    if (heading) info.title = (heading.getAttribute('title') || heading.textContent || '').trim();
  }
  if (!info.title) {
    info.title = (document.title || '').replace(/_哔哩哔哩_bilibili.*$/, '').trim();
  }
  if (!info.upName) {
    const upLink = document.querySelector('.up-name, .up-info--name, a[href*="space.bilibili.com"]');
    if (upLink) info.upName = (upLink.textContent || '').trim();
  }
  if (!info.upName) {
    const match = (document.title || '').match(/_([^_]+)的个人空间_/);
    if (match) info.upName = match[1];
  }

  return info;
}

function reportVideoInfo() {
  const info = pickVideoInfo();
  if (info) dispatch(EVT_VIDEO_INFO, info);
  return info;
}

/* ------------------------------------------------------------------ */
/* 启动                                                                 */
/* ------------------------------------------------------------------ */

/* 启动时先把自己当成「已激活、白名单为空」：
   这样即使 B 站前端在我们拿到真实配置之前就发出了推荐请求，
   也会先被当成「没有可放行内容」处理，而不是原样放过去。
   真实配置到达后 applyConfig 会覆盖它。 */
state.active = true;

/* 启动时先广播一次 bf:ready，告诉隔离环境「我在这里，请把配置发给我」。 */
dispatch(EVT_READY, { version: 1, total: 0 });

window.setTimeout(reportVideoInfo, 0);
window.setTimeout(reportVideoInfo, 800);
window.setTimeout(reportVideoInfo, 2500);
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    scheduleScan();
    reportVideoInfo();
  });
} else {
  scheduleScan();
}

})();

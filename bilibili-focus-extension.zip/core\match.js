/**
 * B 站专注模式 · 白名单匹配
 * 纯逻辑，不依赖 DOM，可在页面 / Service Worker / Node 测试中复用。
 */

const BV_RE = /^BV[0-9A-Za-z]{10}$/;

export function isBvid(value) {
  return typeof value === 'string' && BV_RE.test(value.trim());
}

/** 从任意字符串/URL 中提取 bvid 与 aid */
export function parseVideoRef(input) {
  const text = String(input || '').trim();
  if (!text) return null;

  const bvMatch = text.match(/BV[0-9A-Za-z]{10}/);
  const avMatch = text.match(/av(\d+)/i);
  const result = {};
  if (bvMatch) result.bvid = bvMatch[0];
  if (avMatch) result.aid = Number(avMatch[1]);

  // 纯数字也当成 aid（用户直接粘贴 aid 的情况）
  if (!result.bvid && !result.aid && /^\d{1,12}$/.test(text)) result.aid = Number(text);
  if (!result.bvid && !result.aid) return null;
  return result;
}

export function videoKey(entry) {
  if (!entry) return '';
  if (entry.bvid) return entry.bvid;
  if (entry.aid) return `av${entry.aid}`;
  return '';
}

/** 用于识别「这个条目是不是白名单里的视频」的 id 集合 */
export class Matcher {
  constructor(config) {
    this.config = config || { videos: [], uploaders: [] };
    this.bvids = new Set();
    this.aids = new Set();
    this.mids = new Set();
    this.titleTokens = new Set();

    for (const video of this.config.videos || []) {
      if (video.bvid) this.bvids.add(video.bvid);
      if (video.aid) this.aids.add(String(video.aid));
    }
    for (const up of this.config.uploaders || []) {
      if (up.mid) this.mids.add(String(up.mid));
    }
  }

  get empty() {
    return this.bvids.size === 0 && this.aids.size === 0 && this.mids.size === 0;
  }

  get total() {
    return this.bvids.size + this.mids.size;
  }

  /** 视频是否被放行（bvid 或 aid 命中，或 UP 主被放行） */
  allowsVideo(bvid, aid, upMid) {
    if (bvid && this.bvids.has(bvid)) return true;
    if (aid && this.aids.has(String(aid))) return true;
    if (upMid && this.mids.has(String(upMid))) return true;
    return false;
  }

  /** 条目本身带的身份信息 */
  allowsEntry(entry) {
    if (!entry) return false;
    return this.allowsVideo(entry.bvid, entry.aid, entry.upMid ?? entry.mid);
  }

  allowsUploader(mid) {
    return Boolean(mid) && this.mids.has(String(mid));
  }

  hasBvid(bvid) {
    return Boolean(bvid) && this.bvids.has(bvid);
  }

  hasAid(aid) {
    return Boolean(aid) && this.aids.has(String(aid));
  }

  hasUploader(mid) {
    return this.allowsUploader(mid);
  }
}

export function createMatcher(config) {
  return new Matcher(config);
}

/**
 * 从 B 站各种接口的 item 里尽力抽取身份：
 * 视频卡片 / 动态卡片 / 搜索结果 / 相关推荐 都能覆盖。
 */
export function extractVideoIds(item) {
  if (!item || typeof item !== 'object') return {};

  const out = {};
  const push = (candidate) => {
    if (!candidate) return;
    if (!out.bvid && isBvid(candidate)) out.bvid = candidate.trim();
    else if (!out.aid && typeof candidate === 'number' && Number.isFinite(candidate) && candidate > 0) {
      out.aid = candidate;
    }
  };

  // 结构比较深的候选字段
  const direct = [
    item.bvid,
    item.bv_id,
    item.id,
    item.aid,
    item.avid,
    item.archive?.bvid,
    item.archive?.aid,
    item.args?.bvid,
    item.args?.aid,
    item.reserve?.bvid,
  ];
  for (const value of direct) push(value);

  const args = item.args;
  if (args && typeof args === 'object') {
    if (typeof args.bvid === 'string') push(args.bvid);
    if (typeof args.aid === 'string' && /^\d+$/.test(args.aid)) push(Number(args.aid));
  }

  // 动态卡片
  const major = item.modules?.module_dynamic?.major;
  if (major?.archive?.bvid) push(major.archive.bvid);
  if (major?.archive?.aid) push(major.archive.aid);
  if (major?.archive?.id) push(major.archive.id);
  if (major?.pgc?.jump_url) push(major.pgc.jump_url);

  // 搜索结果里 href 形如 //www.bilibili.com/video/BVxxx
  for (const key of ['arcurl', 'jump_url', 'uri', 'url']) {
    const value = item[key];
    if (typeof value !== 'string') continue;
    const parsed = parseVideoRef(value);
    if (parsed) {
      if (!out.bvid && parsed.bvid) out.bvid = parsed.bvid;
      if (!out.aid && parsed.aid) out.aid = parsed.aid;
    }
  }

  // 兜底：链接里直接带 BV 号
  for (const key of ['link', 'href', 'share_url']) {
    if (typeof item[key] === 'string' && isBvid(item[key])) push(item[key]);
  }

  return out;
}

export function extractUpMid(item) {
  if (!item || typeof item !== 'object') return 0;
  const candidates = [
    item.upMid,
    item.owner?.mid,
    item.author?.mid,
    item.up?.mid,
    item.modules?.module_author?.mid,
    item.mid,
  ];
  for (const value of candidates) {
    const mid = Number(value);
    if (Number.isFinite(mid) && mid > 0) return mid;
  }
  // 搜索结果里有时是 "author" 字符串 + "mid"，或者跳转链接里的 space/数字
  for (const key of ['jump_url', 'uri', 'arcurl']) {
    const value = item[key];
    if (typeof value !== 'string') continue;
    const match = value.match(/space\.bilibili\.com\/(\d+)/);
    if (match) return Number(match[1]);
  }
  return 0;
}

/** 是否是「视频类」卡片（非视频类：广告、番剧、直播、课程等） */
export function isVideoLike(item) {
  if (!item || typeof item !== 'object') return false;
  const goto = String(item.goto || item.card_goto || item.type || '');
  if (goto === 'av' || goto === 'video' || goto === 'archive' || goto === 'ogv') return true;
  if (goto && ['live', 'article', 'pgc', 'bangumi', 'ad', 'special', 'dynamic'].includes(goto)) return false;
  if (typeof item.bvid === 'string' && isBvid(item.bvid)) return true;
  if (item.owner && item.owner.mid) return true;
  if (item.modules?.module_dynamic?.major?.archive) return true;
  return false;
}

/**
 * 视频页 URL 解析：返回 { bvid, p }
 * 注意：这是纯字符串解析，不是 URL API（兼容 Service Worker / Node）
 */
export function parseVideoPageUrl(href) {
  const text = String(href || '');
  const match = text.match(/\/video\/(BV[0-9A-Za-z]{10})/);
  if (!match) return null;
  const pageMatch = text.match(/[?&]p=(\d+)/);
  return { bvid: match[1], p: pageMatch ? Number(pageMatch[1]) : 1 };
}

/* B 站专注模式 · content（由 build.mjs 从 src/ 生成，请勿直接改这个文件） */
(() => {
'use strict';

/* ---- core/storage.js ---- */
/**
 * B 站专注模式 · 数据层
 * 所有页面（content / popup / background）共用同一份 chrome.storage.local 配置。
 */
const STORAGE_KEY = 'focusConfig';

/** 屏蔽项开关。true = 隐藏 */
const DEFAULT_SETTINGS = {
  blockNav: true,          // 顶部导航的 首页 / 热门 / 动态 入口
  blockHot: true,          // 热搜、热榜、排行榜入口
  blockRelated: true,      // 视频页右侧「相关推荐」整栏
  blockComments: true,     // 评论区
  blockSearchReco: true,   // 搜索页顶部的「搜索发现 / 相关搜索」
  blockDynamic: true,      // 动态页时间线
  blockHomeFeed: true,     // 首页信息流
  showBadge: true,         // 扩展图标上显示已屏蔽数量
};
const DEFAULT_CONFIG = {
  version: 1,
  enabled: true,
  pausedUntil: 0,
  settings: { ...DEFAULT_SETTINGS },
  /** [{ bvid, aid, cid, title, upName, upMid, cover, duration, addedAt }] */
  videos: [],
  /** [{ mid, name, face, addedAt }] */
  uploaders: [],
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeEntry(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const out = {};
  if (typeof entry.bvid === 'string' && /^BV[0-9A-Za-z]{10}$/.test(entry.bvid)) {
    out.bvid = entry.bvid;
  }
  if (Number.isFinite(Number(entry.aid)) && Number(entry.aid) > 0) out.aid = Number(entry.aid);
  if (Number.isFinite(Number(entry.cid)) && Number(entry.cid) > 0) out.cid = Number(entry.cid);
  if (!out.bvid && !out.aid) return null;
  out.title = String(entry.title || '').slice(0, 200);
  out.upName = String(entry.upName || '').slice(0, 100);
  out.upMid = Number.isFinite(Number(entry.upMid)) && Number(entry.upMid) > 0 ? Number(entry.upMid) : 0;
  out.cover = String(entry.cover || '').slice(0, 500);
  out.duration = Number.isFinite(Number(entry.duration)) ? Number(entry.duration) : 0;
  out.addedAt = Number.isFinite(Number(entry.addedAt)) ? Number(entry.addedAt) : Date.now();
  return out;
}

function normalizeUploader(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const mid = Number(entry.mid);
  if (!Number.isFinite(mid) || mid <= 0) return null;
  return {
    mid,
    name: String(entry.name || '').slice(0, 100),
    face: String(entry.face || '').slice(0, 500),
    addedAt: Number.isFinite(Number(entry.addedAt)) ? Number(entry.addedAt) : Date.now(),
  };
}

/** 把任意（可能损坏的）读入数据规范成完整配置 */
function normalizeConfig(raw) {
  const base = clone(DEFAULT_CONFIG);
  if (!raw || typeof raw !== 'object') return base;

  if (raw.enabled === false) base.enabled = false;
  const pausedUntil = Number(raw.pausedUntil);
  if (Number.isFinite(pausedUntil) && pausedUntil > 0) base.pausedUntil = pausedUntil;

  if (raw.settings && typeof raw.settings === 'object') {
    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      if (typeof raw.settings[key] === 'boolean') base.settings[key] = raw.settings[key];
    }
  }

  if (Array.isArray(raw.videos)) {
    const seen = new Set();
    for (const item of raw.videos) {
      const entry = normalizeEntry(item);
      if (!entry) continue;
      const key = entry.bvid || `av${entry.aid}`;
      if (seen.has(key)) continue;
      seen.add(key);
      base.videos.push(entry);
    }
  }

  if (Array.isArray(raw.uploaders)) {
    const seen = new Set();
    for (const item of raw.uploaders) {
      const entry = normalizeUploader(item);
      if (!entry || seen.has(entry.mid)) continue;
      seen.add(entry.mid);
      base.uploaders.push(entry);
    }
  }

  return base;
}
async function readConfig() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return normalizeConfig(stored[STORAGE_KEY]);
}
async function writeConfig(config) {
  const normalized = normalizeConfig(config);
  await chrome.storage.local.set({ [STORAGE_KEY]: normalized });
  return normalized;
}

/** 读 → 改 → 写，保证并发安全（Service Worker 单线程，消息天然串行） */
async function updateConfig(mutator) {
  const current = await readConfig();
  const next = (await mutator(current)) || current;
  return writeConfig(next);
}
function onConfigChanged(callback) {
  const listener = (changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY]) return;
    callback(normalizeConfig(changes[STORAGE_KEY].newValue));
  };
  chrome.storage.onChanged.addListener(listener);
  return () => chrome.storage.onChanged.removeListener(listener);
}

/** 当前是否处于「生效中」（启用且未临时放行） */
function isActive(config, now = Date.now()) {
  return Boolean(config && config.enabled && !(config.pausedUntil > now));
}

/** 临时放行剩余秒数，0 表示没有放行 */
function passRemainingSeconds(config, now = Date.now()) {
  if (!config || !(config.pausedUntil > now)) return 0;
  return Math.ceil((config.pausedUntil - now) / 1000);
}

/* ---- core/match.js ---- */
/**
 * B 站专注模式 · 白名单匹配
 * 纯逻辑，不依赖 DOM，可在页面 / Service Worker / Node 测试中复用。
 */

const BV_RE = /^BV[0-9A-Za-z]{10}$/;
function isBvid(value) {
  return typeof value === 'string' && BV_RE.test(value.trim());
}

/** 从任意字符串/URL 中提取 bvid 与 aid */
function parseVideoRef(input) {
  const text = String(input || '').trim();
  if (!text) return null;

  const bvMatch = text.match(/BV[0-9A-Za-z]{10}/);
  const avMatch = text.match(/av(\d+)/i);
  const result = {};
  if (bvMatch) result.bvid = bvMatch[0];
  if (avMatch) result.aid = Number(avMatch[1]);

  // 纯数字也当成 aid（用户直接粘贴 aid 的情况）
  if (!result.bvid && !result.aid && /^\d{1,12}$/.test(text)) result.aid = Number(text);
  if (!result.bvid && !result.aid) return null;
  return result;
}
function videoKey(entry) {
  if (!entry) return '';
  if (entry.bvid) return entry.bvid;
  if (entry.aid) return `av${entry.aid}`;
  return '';
}

/** 用于识别「这个条目是不是白名单里的视频」的 id 集合 */
class Matcher {
  constructor(config) {
    this.config = config || { videos: [], uploaders: [] };
    this.bvids = new Set();
    this.aids = new Set();
    this.mids = new Set();
    this.titleTokens = new Set();

    for (const video of this.config.videos || []) {
      if (video.bvid) this.bvids.add(video.bvid);
      if (video.aid) this.aids.add(String(video.aid));
    }
    for (const up of this.config.uploaders || []) {
      if (up.mid) this.mids.add(String(up.mid));
    }
  }

  get empty() {
    return this.bvids.size === 0 && this.aids.size === 0 && this.mids.size === 0;
  }

  get total() {
    return this.bvids.size + this.mids.size;
  }

  /** 视频是否被放行（bvid 或 aid 命中，或 UP 主被放行） */
  allowsVideo(bvid, aid, upMid) {
    if (bvid && this.bvids.has(bvid)) return true;
    if (aid && this.aids.has(String(aid))) return true;
    if (upMid && this.mids.has(String(upMid))) return true;
    return false;
  }

  /** 条目本身带的身份信息 */
  allowsEntry(entry) {
    if (!entry) return false;
    return this.allowsVideo(entry.bvid, entry.aid, entry.upMid ?? entry.mid);
  }

  allowsUploader(mid) {
    return Boolean(mid) && this.mids.has(String(mid));
  }

  hasBvid(bvid) {
    return Boolean(bvid) && this.bvids.has(bvid);
  }

  hasAid(aid) {
    return Boolean(aid) && this.aids.has(String(aid));
  }

  hasUploader(mid) {
    return this.allowsUploader(mid);
  }
}
function createMatcher(config) {
  return new Matcher(config);
}

/**
 * 从 B 站各种接口的 item 里尽力抽取身份：
 * 视频卡片 / 动态卡片 / 搜索结果 / 相关推荐 都能覆盖。
 */
function extractVideoIds(item) {
  if (!item || typeof item !== 'object') return {};

  const out = {};
  const push = (candidate) => {
    if (!candidate) return;
    if (!out.bvid && isBvid(candidate)) out.bvid = candidate.trim();
    else if (!out.aid && typeof candidate === 'number' && Number.isFinite(candidate) && candidate > 0) {
      out.aid = candidate;
    }
  };

  // 结构比较深的候选字段
  const direct = [
    item.bvid,
    item.bv_id,
    item.id,
    item.aid,
    item.avid,
    item.archive?.bvid,
    item.archive?.aid,
    item.args?.bvid,
    item.args?.aid,
    item.reserve?.bvid,
  ];
  for (const value of direct) push(value);

  const args = item.args;
  if (args && typeof args === 'object') {
    if (typeof args.bvid === 'string') push(args.bvid);
    if (typeof args.aid === 'string' && /^\d+$/.test(args.aid)) push(Number(args.aid));
  }

  // 动态卡片
  const major = item.modules?.module_dynamic?.major;
  if (major?.archive?.bvid) push(major.archive.bvid);
  if (major?.archive?.aid) push(major.archive.aid);
  if (major?.archive?.id) push(major.archive.id);
  if (major?.pgc?.jump_url) push(major.pgc.jump_url);

  // 搜索结果里 href 形如 //www.bilibili.com/video/BVxxx
  for (const key of ['arcurl', 'jump_url', 'uri', 'url']) {
    const value = item[key];
    if (typeof value !== 'string') continue;
    const parsed = parseVideoRef(value);
    if (parsed) {
      if (!out.bvid && parsed.bvid) out.bvid = parsed.bvid;
      if (!out.aid && parsed.aid) out.aid = parsed.aid;
    }
  }

  // 兜底：链接里直接带 BV 号
  for (const key of ['link', 'href', 'share_url']) {
    if (typeof item[key] === 'string' && isBvid(item[key])) push(item[key]);
  }

  return out;
}
function extractUpMid(item) {
  if (!item || typeof item !== 'object') return 0;
  const candidates = [
    item.upMid,
    item.owner?.mid,
    item.author?.mid,
    item.up?.mid,
    item.modules?.module_author?.mid,
    item.mid,
  ];
  for (const value of candidates) {
    const mid = Number(value);
    if (Number.isFinite(mid) && mid > 0) return mid;
  }
  // 搜索结果里有时是 "author" 字符串 + "mid"，或者跳转链接里的 space/数字
  for (const key of ['jump_url', 'uri', 'arcurl']) {
    const value = item[key];
    if (typeof value !== 'string') continue;
    const match = value.match(/space\.bilibili\.com\/(\d+)/);
    if (match) return Number(match[1]);
  }
  return 0;
}

/** 是否是「视频类」卡片（非视频类：广告、番剧、直播、课程等） */
function isVideoLike(item) {
  if (!item || typeof item !== 'object') return false;
  const goto = String(item.goto || item.card_goto || item.type || '');
  if (goto === 'av' || goto === 'video' || goto === 'archive' || goto === 'ogv') return true;
  if (goto && ['live', 'article', 'pgc', 'bangumi', 'ad', 'special', 'dynamic'].includes(goto)) return false;
  if (typeof item.bvid === 'string' && isBvid(item.bvid)) return true;
  if (item.owner && item.owner.mid) return true;
  if (item.modules?.module_dynamic?.major?.archive) return true;
  return false;
}

/**
 * 视频页 URL 解析：返回 { bvid, p }
 * 注意：这是纯字符串解析，不是 URL API（兼容 Service Worker / Node）
 */
function parseVideoPageUrl(href) {
  const text = String(href || '');
  const match = text.match(/\/video\/(BV[0-9A-Za-z]{10})/);
  if (!match) return null;
  const pageMatch = text.match(/[?&]p=(\d+)/);
  return { bvid: match[1], p: pageMatch ? Number(pageMatch[1]) : 1 };
}

/* ---- content/ui.js ---- */
/**
 * B 站专注模式 · 视频页悬浮按钮（Shadow DOM，避免被 B 站样式污染）
 */
const HOST_TAG = 'bf-focus-pill';

const STYLE = `
  :host { all: initial; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .wrap {
    position: fixed;
    z-index: 2147483000;
    right: 18px;
    bottom: 96px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
    font-size: 13px;
    line-height: 1;
    user-select: none;
  }
  .pill {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    height: 38px;
    padding: 0 14px 0 12px;
    border: 0;
    border-radius: 19px;
    color: #fff;
    background: linear-gradient(135deg, #fb7299 0%, #fc9db5 100%);
    box-shadow: 0 6px 20px rgba(251, 114, 153, .38), 0 1px 2px rgba(0,0,0,.08);
    cursor: pointer;
    transition: transform .18s ease, box-shadow .18s ease, background .18s ease, opacity .18s ease;
    font: inherit;
    font-weight: 600;
  }
  .pill:hover { transform: translateY(-1px); box-shadow: 0 9px 26px rgba(251,114,153,.45); }
  .pill:active { transform: translateY(0) scale(.98); }
  .pill[data-state="on"] {
    background: rgba(255,255,255,.94);
    color: #d63b63;
    box-shadow: 0 4px 16px rgba(0,0,0,.14), inset 0 0 0 1px #fbd0dc;
    backdrop-filter: saturate(1.6) blur(8px);
  }
  .pill[data-state="on"]:hover { background: #fff; }
  .pill[data-state="up"] {
    background: rgba(255,255,255,.94);
    color: #555;
    box-shadow: 0 4px 16px rgba(0,0,0,.12), inset 0 0 0 1px #e6e6e6;
  }
  .dot {
    width: 7px; height: 7px; border-radius: 50%;
    background: #fff; flex: none;
  }
  .pill[data-state="on"] .dot, .pill[data-state="up"] .dot { background: #fb7299; }
  svg { flex: none; display: block; }
  .toast {
    position: fixed;
    right: 18px;
    bottom: 146px;
    max-width: 240px;
    padding: 9px 12px;
    border-radius: 10px;
    background: rgba(24, 25, 28, .92);
    color: #fff;
    font-size: 12px;
    line-height: 1.5;
    box-shadow: 0 8px 24px rgba(0,0,0,.24);
    opacity: 0;
    transform: translateY(6px);
    transition: opacity .2s ease, transform .2s ease;
    pointer-events: none;
  }
  .toast.show { opacity: 1; transform: translateY(0); }
  .wrap.hidden { display: none; }
`;

const ICON_PLUS = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 3.2v9.6M3.2 8h9.6" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>';
const ICON_CHECK = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.4 8.4l3 3 6.2-6.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function createPill() {
  const host = document.createElement(HOST_TAG);
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = STYLE;

  const wrap = document.createElement('div');
  wrap.className = 'wrap hidden';

  const pill = document.createElement('button');
  pill.type = 'button';
  pill.className = 'pill';
  pill.dataset.state = 'off';
  pill.setAttribute('title', '把当前视频加入白名单');

  const dot = document.createElement('span');
  dot.className = 'dot';
  const icon = document.createElement('span');
  icon.innerHTML = ICON_PLUS;
  const label = document.createElement('span');
  label.textContent = '加入白名单';

  pill.append(dot, icon, label);
  wrap.append(pill);

  const toast = document.createElement('div');
  toast.className = 'toast';

  shadow.append(style, wrap, toast);

  /* 上下拖动：记住位置，刷新后保持 */
  let drag = null;
  try {
    const saved = JSON.parse(localStorage.getItem('bf-pill-pos') || 'null');
    if (saved && Number.isFinite(saved.bottom)) wrap.style.bottom = `${saved.bottom}px`;
  } catch {
    /* ignore */
  }

  pill.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    drag = { startY: event.clientY, startBottom: wrap.getBoundingClientRect().bottom, moved: false };
  });
  window.addEventListener('pointermove', (event) => {
    if (!drag) return;
    const delta = drag.startY - event.clientY;
    if (Math.abs(delta) > 3) drag.moved = true;
    if (!drag.moved) return;
    const bottom = Math.min(Math.max(drag.startBottom + delta, 8), window.innerHeight - 60);
    wrap.style.bottom = `${bottom}px`;
  });
  window.addEventListener('pointerup', () => {
    if (!drag) return;
    if (drag.moved) {
      try {
        localStorage.setItem('bf-pill-pos', JSON.stringify({ bottom: parseFloat(wrap.style.bottom) || 96 }));
      } catch {
        /* ignore */
      }
    }
    drag = null;
  });

  let toastTimer = 0;
  function showToast(text) {
    toast.textContent = text;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2200);
  }

  return {
    host,
    show() {
      wrap.classList.remove('hidden');
    },
    hide() {
      wrap.classList.add('hidden');
    },
    get visible() {
      return !wrap.classList.contains('hidden');
    },
    setVideoInWhitelist(inWhitelist) {
      if (inWhitelist) {
        pill.dataset.state = 'on';
        icon.innerHTML = ICON_CHECK;
        label.textContent = '已加入白名单';
        pill.setAttribute('title', '点击移出白名单');
      } else {
        pill.dataset.state = 'off';
        icon.innerHTML = ICON_PLUS;
        label.textContent = '加入白名单';
        pill.setAttribute('title', '把当前视频加入白名单');
      }
    },
    setUploaderInWhitelist(inWhitelist) {
      if (inWhitelist && pill.dataset.state !== 'on') {
        pill.dataset.state = 'up';
        icon.innerHTML = ICON_CHECK;
        label.textContent = 'UP 主已放行';
      }
    },
    onClick(handler) {
      pill.addEventListener('click', (event) => {
        if (drag?.moved) return;
        event.preventDefault();
        event.stopPropagation();
        handler();
      });
    },
    toast: showToast,
  };
}

/* ---- content/content.js ---- */
/**
 * B 站专注模式 · 隔离环境内容脚本
 *
 * 职责：
 *   1. 从 chrome.storage 读配置，交给 MAIN world 的 page-hook 去过滤接口；
 *   2. 注入 / 撤下页面屏蔽 CSS；
 *   3. 视频页悬浮「加入白名单」按钮；
 *   4. 首页过滤后如果只剩空列表，给一个「今天没有待看的视频」的空状态。
 */

const EVT_VIDEO_INFO = 'bf:video-info';
const EVT_BLOCKED = 'bf:blocked';
const EMPTY_TAG = 'bf-focus-empty';

const state = {
  config: null,
  matcher: new Matcher(null),
  video: null,
  styleEl: null,
  pill: null,
  activeRequested: false,
  lastPaused: false,
};

/* ------------------------------------------------------------------ */
/* 工具                                                                 */
/* ------------------------------------------------------------------ */

function $selector(selectors) {
  for (const selector of selectors) {
    const node = document.querySelector(selector);
    if (node) return node;
  }
  return null;
}

function currentPageKind() {
  const { pathname } = location;
  if (pathname.startsWith('/video/')) return 'video';
  if (pathname === '/' || pathname === '') return 'home';
  if (pathname.startsWith('/search') || location.hostname.startsWith('search.')) return 'search';
  if (pathname.startsWith('/v/dynamic') || pathname.startsWith('/dynamic')) return 'dynamic';
  if (location.hostname === 't.bilibili.com') return 'dynamic';
  if (pathname.startsWith('/v/popular')) return 'popular';
  if (pathname.startsWith('/bangumi')) return 'bangumi';
  return 'other';
}

async function send(message) {
  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

/* ------------------------------------------------------------------ */
/* CSS                                                                  */
/* ------------------------------------------------------------------ */

async function injectCss() {
  if (state.styleEl) return;
  const style = document.createElement('style');
  style.id = 'bf-focus-style';
  try {
    const url = chrome.runtime.getURL('content/block.css');
    const response = await fetch(url);
    const text = await response.text();
    // 防御：拿到的必须像一张样式表，避免接口异常时把 JSON 塞进 <style>
    if (!text || text.length < 20 || text.includes('"code":') || !text.includes('{')) {
      throw new Error('样式表内容异常');
    }
    style.textContent = text;
  } catch {
    return;
  }
  (document.head || document.documentElement).appendChild(style);
  state.styleEl = style;
  // 样式后到可能覆盖不到已打标记的元素，补一次
  tagNav();
}

function removeCss() {
  state.styleEl?.remove();
  state.styleEl = null;
}

/* ------------------------------------------------------------------ */
/* 空状态                                                               */
/* ------------------------------------------------------------------ */

function renderEmptyState() {
  if (document.querySelector(EMPTY_TAG)) return;

  const host = document.createElement(EMPTY_TAG);
  const shadow = host.attachShadow({ mode: 'open' });
  shadow.innerHTML = `
    <style>
      :host { all: initial; display: block; }
      .card {
        max-width: 520px;
        margin: 56px auto 80px;
        padding: 34px 28px;
        border-radius: 18px;
        background: #fff;
        border: 1px solid #f1e4e9;
        box-shadow: 0 12px 40px rgba(251, 114, 153, .10);
        text-align: center;
        font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
        color: #18191c;
      }
      .logo {
        width: 52px; height: 52px; margin: 0 auto 18px;
        border-radius: 16px;
        background: linear-gradient(135deg, #fb7299, #fc9db5);
        display: grid; place-items: center;
        box-shadow: 0 8px 22px rgba(251,114,153,.35);
      }
      h2 { font-size: 17px; font-weight: 600; margin: 0 0 8px; letter-spacing: .2px; }
      p { font-size: 13px; color: #61666d; line-height: 1.7; margin: 0 0 22px; }
      .row { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
      button {
        height: 36px; padding: 0 18px; border-radius: 18px; border: 1px solid #e3e5e7;
        background: #fff; color: #18191c; font: inherit; font-size: 13px; font-weight: 500;
        cursor: pointer; transition: all .16s ease;
      }
      button:hover { border-color: #fb7299; color: #fb7299; }
      button.primary {
        border: 0; color: #fff;
        background: linear-gradient(135deg, #fb7299, #fc9db5);
        box-shadow: 0 6px 16px rgba(251,114,153,.32);
      }
      button.primary:hover { color: #fff; transform: translateY(-1px); }
      .hint { margin-top: 16px; font-size: 11px; color: #9499a0; line-height: 1.6; }
      kbd {
        padding: 1px 5px; border-radius: 4px; background: #f4f5f7; border: 1px solid #e3e5e7;
        font-family: ui-monospace, Menlo, monospace; font-size: 10px;
      }
    </style>
    <div class="card">
      <div class="logo">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M6 4.5h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-1.2l1.4 2-1.7 1.2-1.9-2.7H9.4l-1.9 2.7L5.8 19.5l1.4-2H6a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2Z" fill="rgba(255,255,255,.95)"/>
          <path d="M10 9.2v4.6l4-2.3L10 9.2Z" fill="#fb7299"/>
        </svg>
      </div>
      <h2>今天没有待看的视频</h2>
      <p>推荐流已经清空，只显示你亲自放进白名单的视频。<br>想看点什么，就去加一个吧。</p>
      <div class="row">
        <button class="primary" id="open">打开白名单管理</button>
        <button id="pass">临时放行 30 分钟</button>
      </div>
      <div class="hint">任意视频页右下角有「加入白名单」按钮，也可以点工具栏里的 <kbd>B</kbd> 图标。</div>
    </div>
  `;

  shadow.getElementById('open')?.addEventListener('click', () => {
    send({ type: 'openOptions' });
  });
  shadow.getElementById('pass')?.addEventListener('click', async () => {
    const result = await send({ type: 'setPass', minutes: 30 });
    if (result?.ok) host.remove();
  });

  const anchor = $selector(['#reco_list', '.bili-feed4-layout', '.feed2', '.container', 'main']) || document.body;
  anchor.appendChild(host);
}

function maybeEmptyState() {
  if (location.pathname !== '/' || !state.activeRequested) return;
  if (state.matcher.empty) return;
  // 只数「可见的」卡片；被隐藏的骨架/广告不算
  const visibleCards = [...document.querySelectorAll('.bili-video-card, .feed-card')].filter(
    (card) => !card.classList.contains('bf-card-hidden') && getComputedStyle(card).display !== 'none'
  );
  if (visibleCards.length > 0) {
    document.querySelector(EMPTY_TAG)?.remove();
    return;
  }
  // 等一等等页面渲染，避免一闪而过的空状态
  window.setTimeout(() => {
    if (!state.activeRequested) return;
    const stillVisible = [...document.querySelectorAll('.bili-video-card, .feed-card')].filter(
      (card) => !card.classList.contains('bf-card-hidden') && getComputedStyle(card).display !== 'none'
    );
    if (stillVisible.length > 0) {
      document.querySelector(EMPTY_TAG)?.remove();
      return;
    }
    renderEmptyState();
  }, 1200);
}

/* ------------------------------------------------------------------ */
/* 悬浮按钮                                                             */
/* ------------------------------------------------------------------ */

function ensurePill() {
  if (state.pill) return state.pill;
  const pill = createPill();
  state.pill = pill;
  (document.body || document.documentElement).appendChild(pill.host);
  pill.onClick(async () => {
    if (!state.video) {
      pill.toast('还没识别到这个视频，刷新一下页面试试');
      return;
    }
    const result = await send({ type: 'toggleVideo', video: state.video });
    if (!result?.ok) {
      pill.toast('保存失败：' + (result?.error || '未知错误'));
      return;
    }
    if (result.action === 'added') {
      pill.setVideoInWhitelist(true);
      pill.toast('已加入白名单，它会出现在首页');
    } else {
      pill.setVideoInWhitelist(false);
      pill.toast('已移出白名单');
    }
  });
  return pill;
}

function applyPill() {
  if (!state.config || !isActive(state.config) || !state.video?.isVideoPage) {
    state.pill?.hide();
    return;
  }
  const pill = ensurePill();
  pill.show();
  const inList = state.matcher.hasBvid(state.video.bvid) || state.matcher.hasAid(state.video.aid);
  pill.setVideoInWhitelist(inList);
  if (!inList) pill.setUploaderInWhitelist(state.matcher.hasUploader(state.video.upMid));
}

/* ------------------------------------------------------------------ */
/* 顶部导航：按链接路径精确隐藏「首页 / 热门 / 动态」                    */
/* ------------------------------------------------------------------ */

function isBlockedNavLink(anchor) {
  const href = anchor.getAttribute('href') || '';
  if (!href) return false;
  let url;
  try {
    url = new URL(href, location.href);
  } catch {
    return false;
  }
  if (!/(^|\.)bilibili\.com$/i.test(url.hostname)) return false;
  const path = url.pathname.replace(/\/+$/, '') || '/';

  // 首页（只认根路径，不误伤 /v/channel 这类）
  if (path === '/') return true;
  // 热门 / 排行榜
  if (path === '/v/popular' || path.startsWith('/v/popular/')) return true;
  if (path === '/v/ranking' || path.startsWith('/v/ranking/')) return true;
  // 动态（t.bilibili.com 首页 或 /v/dynamic）
  if (url.hostname.toLowerCase() === 't.bilibili.com' && path === '/') return true;
  if (path === '/v/dynamic' || path.startsWith('/v/dynamic/')) return true;
  return false;
}

function tagNav() {
  const navRoot = document.querySelector('.bili-header, header, .mini-header');
  if (!navRoot) return;
  const enabled = Boolean(state.config?.settings?.blockNav);

  // 先清掉上一轮的标记，避免误标残留
  for (const node of navRoot.querySelectorAll('.bf-nav-hidden')) {
    node.classList.remove('bf-nav-hidden');
  }
  if (!enabled) return;

  for (const anchor of navRoot.querySelectorAll('a[href]')) {
    if (!isBlockedNavLink(anchor)) continue;

    // 只往上找到「一行导航项」这一层，绝不越过它去标父级容器。
    // 顺序：B 站自己的 entry/图标 item → 单链接的 li → 链接自身。
    const item =
      anchor.closest(
        '[class*="left-entry__item"], [class*="right-entry__item"], [class*="channel-icons__item"], [class*="nav-item"]'
      ) ||
      (anchor.parentElement && anchor.parentElement.tagName === 'LI' ? anchor.parentElement : null) ||
      anchor;
    if (!item) continue;
    // 安全阀：不标 header 本身、不标宽容器、不标含多个链接的容器
    if (item === navRoot) continue;
    if (item === document.body || item === document.documentElement) continue;
    if (item.querySelectorAll('a[href]').length > 1) continue;
    item.classList.add('bf-nav-hidden');
  }
}

let navTimer = 0;
function scheduleTagNav() {
  if (navTimer) return;
  navTimer = window.setTimeout(() => {
    navTimer = 0;
    if (state.activeRequested) tagNav();
  }, 400);
}

/* ------------------------------------------------------------------ */
/* 配置同步                                                             */
/* ------------------------------------------------------------------ */

/** 把配置发给页面世界的 page-hook。
 *  world:MAIN 的脚本和 content script 是两个独立 JS 世界，window 上的对象不共享，
 *  只有 DOM 事件能跨世界传递，所以统一走 document 上的 CustomEvent。 */
function pushConfigToPage() {
  if (!state.config) return false;
  document.dispatchEvent(new CustomEvent('bf:set-config', { detail: state.config }));
  return true;
}

function publishConfig() {
  const config = state.config;
  state.matcher = new Matcher(config);
  document.documentElement?.setAttribute('data-bf-page', currentPageKind());
  document.documentElement?.setAttribute('data-bf-active', isActive(config) ? '1' : '');
  document.documentElement?.setAttribute(
    'data-bf-block-comments',
    config?.settings?.blockComments ? '1' : ''
  );
  pushConfigToPage();
}

function applyAll() {
  if (!state.config) return;
  state.activeRequested = isActive(state.config);
  if (state.activeRequested) {
    injectCss();
    document.documentElement.setAttribute('data-bf-active', '1');
  } else {
    removeCss();
    document.documentElement.removeAttribute('data-bf-active');
    document.documentElement.removeAttribute('data-bf-block-comments');
    document.querySelector(EMPTY_TAG)?.remove();
  }
  tagNav();
  applyPill();
  window.setTimeout(maybeEmptyState, 1800);
}

/* page-hook 在 document_start 就绪并广播 bf:ready；
   我们收到后把配置发过去，另外自己也敲门 + 补发几次，防止时序错过。 */
function handshake() {
  let sent = false;
  const sendConfig = () => {
    if (!state.config) return;
    if (pushConfigToPage()) sent = true;
  };
  sendConfig();
  window.addEventListener('bf:ready', () => {
    if (!sent) sendConfig();
  });
  window.setTimeout(sendConfig, 120);
  window.setTimeout(sendConfig, 500);
  window.setTimeout(sendConfig, 1500);

  // 我们也主动敲门，防止 page-hook 的 bf:ready 早于我们的监听
  document.dispatchEvent(new CustomEvent('bf:request'));
}

async function boot() {
  state.config = await readConfig();
  publishConfig();
  applyAll();
  handshake();

  // 顶部导航是懒加载/换路由重绘的，持续打标记
  const navObserver = new MutationObserver(() => scheduleTagNav());
  const observeTarget = document.documentElement || document;
  navObserver.observe(observeTarget, { childList: true, subtree: true });

  onConfigChanged((config) => {
    state.config = config;
    publishConfig();
    applyAll();
  });

  state.lastPaused = state.config.pausedUntil > Date.now();
  // 临时放行到点自动恢复：每 20 秒对一次表
  window.setInterval(() => {
    if (!state.config) return;
    const paused = state.config.pausedUntil > Date.now();
    if (paused !== state.lastPaused) {
      state.lastPaused = paused;
      applyAll();
    }
    const remaining = passRemainingSeconds(state.config);
    if (remaining > 0) {
      document.documentElement.setAttribute('data-bf-pass', String(remaining));
    } else {
      document.documentElement.removeAttribute('data-bf-pass');
    }
  }, 20000);
}

/* ------------------------------------------------------------------ */
/* 与 page-hook 的事件                                                  */
/* ------------------------------------------------------------------ */

window.addEventListener(EVT_VIDEO_INFO, (event) => {
  const info = event.detail;
  if (!info || !isBvid(info.bvid)) return;
  state.video = info;
  applyPill();
});

window.addEventListener(EVT_BLOCKED, (event) => {
  const count = Number(event.detail?.count || 0);
  if (!Number.isFinite(count)) return;
  document.documentElement.setAttribute('data-bf-blocked', String(count));
  // 徽标显示白名单数量，由 background 在开关/增删时统一切换，这里不重复写。
});

/* page-hook 判断首页已经空了 → 显示空状态 */
window.addEventListener('bf:feed-empty', (event) => {
  if (event.detail?.empty) renderEmptyState();
  else document.querySelector(EMPTY_TAG)?.remove();
});

window.addEventListener('popstate', () => {
  // 站内换视频不会重新加载页面，敲一下 page-hook 让它重新上报
  window.setTimeout(() => document.dispatchEvent(new CustomEvent('bf:report')), 400);
  window.setTimeout(refreshPageKind, 400);
});

/* 站内路由切换后页面类型会变（首页 → 搜索页等），CSS 变量要跟着更新 */
function refreshPageKind() {
  if (!state.config) return;
  document.documentElement?.setAttribute('data-bf-page', currentPageKind());
  tagNav();
  window.setTimeout(maybeEmptyState, 1200);
}

let lastKindHref = location.href;
window.setInterval(() => {
  if (location.href === lastKindHref) return;
  lastKindHref = location.href;
  refreshPageKind();
}, 900);

/* 快捷键 Alt+Shift+B：加入 / 移出当前视频 */
window.addEventListener('keydown', async (event) => {
  if (!event.altKey || !event.shiftKey || event.code !== 'KeyB') return;
  if (!state.video?.isVideoPage) return;
  event.preventDefault();
  const result = await send({ type: 'toggleVideo', video: state.video });
  if (result?.ok) {
    state.pill?.setVideoInWhitelist(result.action === 'added');
    state.pill?.toast(result.action === 'added' ? '已加入白名单' : '已移出白名单');
  }
});

boot();

})();

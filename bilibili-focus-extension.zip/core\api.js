/**
 * B 站专注模式 · 接口过滤
 *
 * B 站前端是 SPA，卡片来自后台接口。与其和 DOM 打架，
 * 不如在接口返回时直接把「不在白名单里的卡片」从 JSON 里削掉：
 * 页面拿到的数据本身只剩你要看的视频，连滚动加载都干净。
 *
 * 不依赖 DOM / chrome API，可在 Node 里直接测。
 */
import { extractVideoIds, extractUpMid, isVideoLike, parseVideoRef } from './match.js';

/** 需要接管的接口（命中就过滤，其余一律放行） */
const RULES = [
  { id: 'home', path: /\/x\/web-interface\/(?:wbi\/)?index\/top\/feed\/rcmd/, policy: 'feed' },
  { id: 'home-feed', path: /\/x\/web-interface\/(?:wbi\/)?index\/top\/feed\//, policy: 'feed' },
  { id: 'related', path: /\/x\/web-interface\/(?:wbi\/)?archive\/(?:related|relation)/, policy: 'drop' },
  { id: 'search', path: /\/x\/web-interface\/(?:wbi\/)?search\/(?:type|all\/v2)/, policy: 'search' },
  { id: 'dynamic', path: /\/x\/polymer\/web-dynamic\/v1\/feed\/all/, policy: 'drop' },
  { id: 'popular', path: /\/x\/web-interface\/(?:wbi\/)?popular(?:\/|$|\?)/, policy: 'feed' },
  { id: 'ranking', path: /\/x\/web-interface\/(?:wbi\/)?ranking\/v2/, policy: 'feed' },
  { id: 'live', path: /\/xlive\/web-interface\/v1\/get_(?:recommend|list_by_area)/, policy: 'feed' },
];

export function classifyEndpoint(url) {
  if (!url) return null;
  const text = String(url);
  if (!/bilibili\.com|biliapi/.test(text)) return null;
  for (const rule of RULES) {
    if (rule.path.test(text)) return rule;
  }
  return null;
}

export function shouldIntercept(url) {
  return Boolean(classifyEndpoint(url));
}

const LIST_KEYS = ['item', 'items', 'list', 'archives', 'videos', 'result'];

function noteBlocked(stats, ids) {
  stats.blocked += 1;
  if (ids.bvid) stats.seen.add(ids.bvid);
  else if (ids.aid) stats.seen.add(`av${ids.aid}`);
}

/** 过滤数组里的卡片，返回删除数量 */
/** 明确的「非视频」内容类型：小广告、直播、番剧、专栏等 */
const NON_VIDEO_GOTO = new Set(['ad', 'live', 'pgc', 'bangumi', 'article', 'special', 'course', 'ogv']);

/**
 * 过滤数组里的卡片。
 * 策略（白名单模式的严格版）：feed / 搜索 / 动态里，凡是不在白名单中的卡片一律删除，
 * 包括认不出 BV 号的广告、直播、番剧等推荐位。
 * 唯一例外是页面渲染必需的「配置占位」对象（没有 goto / bvid / owner 的纯数据对象）。
 */
function filterArray(arr, matcher, stats) {
  if (!Array.isArray(arr)) return 0;
  let removed = 0;
  for (let i = arr.length - 1; i >= 0; i -= 1) {
    const item = arr[i];
    if (!item || typeof item !== 'object') continue;

    const ids = extractVideoIds(item);
    const upMid = extractUpMid(item);
    if (matcher.allowsVideo(ids.bvid, ids.aid, upMid)) continue;

    const goto = String(item.goto || item.card_goto || item.type || '').toLowerCase();
    const looksLikeCard =
      Boolean(ids.bvid || ids.aid) ||
      Boolean(item.owner || item.card_goto || item.modules || item.args) ||
      [...NON_VIDEO_GOTO].some((type) => goto.includes(type));

    if (!looksLikeCard) continue; // 纯配置对象 / 占位字段，不能动

    arr.splice(i, 1);
    removed += 1;
    noteBlocked(stats, ids);
  }
  return removed;
}

/** 搜索接口：保持 result_type，只过滤 video 桶 */
function filterSearchResult(result, matcher, stats) {
  if (!result || typeof result !== 'object') return 0;
  let removed = 0;
  for (const key of Object.keys(result)) {
    const bucket = result[key];
    if (!Array.isArray(bucket) || bucket.length === 0) continue;
    const type = String(bucket[0]?.result_type || key);
    if (type !== 'video' && key !== 'video') continue;
    removed += filterArray(bucket, matcher, stats);
  }
  return removed;
}

/** 递归找视频数组并过滤（首页 feed、相关推荐、热门、动态都能覆盖） */
function filterPayload(node, matcher, stats, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 6) return 0;
  if (Array.isArray(node)) return filterArray(node, matcher, stats);

  let removed = 0;
  for (const key of Object.keys(node)) {
    const child = node[key];
    if (Array.isArray(child)) {
      if (child.some((item) => item && typeof item === 'object' && (item.bvid || item.card_goto || item.owner || item.modules))) {
        removed += filterArray(child, matcher, stats);
      }
    } else if (child && typeof child === 'object') {
      removed += filterPayload(child, matcher, stats, depth + 1);
    }
  }
  return removed;
}

/**
 * 主入口：就地修改 json 里的卡片列表。
 * @returns {{applied:boolean, removed:number, ids:string[]}}
 */
export function filterApiJson(url, json, matcher) {
  const rule = classifyEndpoint(url);
  if (!rule || !json || typeof json !== 'object') {
    return { applied: false, removed: 0, ids: [] };
  }
  if (json.code !== undefined && Number(json.code) !== 0) {
    return { applied: false, removed: 0, ids: [] };
  }

  const stats = { blocked: 0, seen: new Set() };
  if (rule.policy === 'search') {
    filterSearchResult(json.data?.result || json.result, matcher, stats);
  } else {
    filterPayload(json, matcher, stats);
  }

  return { applied: true, removed: stats.blocked, ids: [...stats.seen] };
}

export { isVideoLike, parseVideoRef };

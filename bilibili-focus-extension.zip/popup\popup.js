/**
 * B 站专注模式 · 弹窗 / 管理大窗口
 * 同一个页面两种尺寸：popup 默认；?view=full 时变成整页管理界面。
 * ?demo=1 用示例数据渲染，方便在浏览器里直接预览设计稿（不依赖扩展环境）。
 */
import { readConfig, onConfigChanged, isActive, passRemainingSeconds, DEFAULT_SETTINGS } from '../core/storage.js';
import { parseVideoRef, isBvid } from '../core/match.js';

const params = new URLSearchParams(location.search);
const isFull = params.get('view') === 'full';
const isDemo = params.get('demo') === '1';
if (isFull) document.body.classList.add('view-full');

const DEMO_CONFIG = {
  version: 1,
  enabled: true,
  pausedUntil: 0,
  settings: { ...DEFAULT_SETTINGS },
  videos: [
    {
      bvid: 'BV1GJ411x7h7',
      aid: 170001,
      cid: 12345,
      title: '【硬核】从零手写一个浏览器扩展：Content Script 与页面世界的那点事',
      upName: '科技老白',
      upMid: 111,
      cover: '',
      duration: 1245,
      addedAt: Date.now(),
    },
    {
      bvid: 'BV1xx411c7mD',
      aid: 170002,
      title: '三小时讲完线性代数，考试前夜救命版',
      upName: '数学小酒馆',
      upMid: 222,
      cover: '',
      duration: 10800,
      addedAt: Date.now() - 86400000,
    },
    {
      bvid: 'BV1yy411c7mE',
      aid: 170003,
      title: '我用一周时间复刻了《双城之战》里的一帧动画',
      upName: '画画的老王',
      upMid: 333,
      cover: '',
      duration: 903,
      addedAt: Date.now() - 172800000,
    },
  ],
  uploaders: [
    { mid: 222, name: '数学小酒馆', face: '', addedAt: Date.now() },
    { mid: 444, name: '某位只更新代码的 UP 主', face: '', addedAt: Date.now() },
  ],
};

/** 预览模式：没有扩展存储环境时用示例数据 + 空实现 */
const chromeAvailable = typeof chrome !== 'undefined' && Boolean(chrome?.storage?.local?.get);
if (!chromeAvailable && (isDemo || isFull)) {
  window.__DEMO__ = true;
  window.chrome = {
    runtime: {
      getURL: (path) => '../' + path,
      sendMessage: async () => ({ ok: true, config: DEMO_CONFIG, action: 'added' }),
    },
    storage: {
      local: {
        get: async () => ({ focusConfig: DEMO_CONFIG }),
        set: async () => {},
      },
      onChanged: { addListener() {}, removeListener() {} },
    },
    tabs: {
      query: async () => [
        {
          id: 1,
          url: 'https://www.bilibili.com/video/BV1GJ411x7h7',
          title: '【硬核】从零手写一个浏览器扩展',
        },
      ],
      create: () => {},
      onActivated: { addListener() {} },
      onUpdated: { addListener() {} },
    },
  };
  window.__demoReadConfig = () => JSON.parse(JSON.stringify(DEMO_CONFIG));
}

const els = {
  status: document.getElementById('status'),
  passBtn: document.getElementById('passBtn'),
  passBanner: document.getElementById('passBanner'),
  passText: document.getElementById('passText'),
  passCancel: document.getElementById('passCancel'),
  addCurrent: document.getElementById('addCurrent'),
  videoInput: document.getElementById('videoInput'),
  addInput: document.getElementById('addInput'),
  videoList: document.getElementById('videoList'),
  videoEmpty: document.getElementById('videoEmpty'),
  uploaderList: document.getElementById('uploaderList'),
  uploaderEmpty: document.getElementById('uploaderEmpty'),
  midInput: document.getElementById('midInput'),
  addMid: document.getElementById('addMid'),
  settingsList: document.getElementById('settingsList'),
  countVideos: document.getElementById('countVideos'),
  countUploaders: document.getElementById('countUploaders'),
  exportBtn: document.getElementById('exportBtn'),
  importBtn: document.getElementById('importBtn'),
  importFile: document.getElementById('importFile'),
  openFull: document.getElementById('openFull'),
  toast: document.getElementById('toast'),
};

const SETTING_META = [
  { key: 'blockNav', name: '顶部导航入口', desc: '隐藏「首页 / 热门 / 动态」这几个入口' },
  { key: 'blockHot', name: '热搜 / 热榜', desc: '隐藏顶部热搜榜和频道里的排行入口' },
  { key: 'blockRelated', name: '视频页右侧相关推荐', desc: '整栏收起，播放器自动占满宽度' },
  { key: 'blockComments', name: '评论区', desc: '视频下方评论区整个隐藏' },
  { key: 'blockSearchReco', name: '搜索页的推荐词', desc: '「搜索发现 / 相关搜索」不出现' },
  { key: 'blockDynamic', name: '动态时间线', desc: '动态页直接清空' },
  { key: 'blockHomeFeed', name: '首页信息流', desc: '非白名单视频不进首页（核心开关）' },
  { key: 'showBadge', name: '图标上的数字', desc: '工具栏图标显示白名单视频数量' },
];

let config = null;
let currentTab = null;
let toastTimer = 0;

/* ------------------------------------------------------------------ */

function toast(text) {
  els.toast.textContent = text;
  els.toast.hidden = false;
  requestAnimationFrame(() => els.toast.classList.add('show'));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    els.toast.classList.remove('show');
    setTimeout(() => {
      els.toast.hidden = true;
    }, 220);
  }, 2400);
}

async function send(message) {
  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[ch]));
}

function formatDuration(seconds) {
  const total = Number(seconds);
  if (!Number.isFinite(total) || total <= 0) return '';
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = Math.floor(total % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function applyConfig(next) {
  config = next;
  renderStatus();
  renderVideos();
  renderUploaders();
  renderSettings();
  updateAddCurrent();
}

/* ------------------------------------------------------------------ */
/* 状态                                                                 */
/* ------------------------------------------------------------------ */

function renderStatus() {
  if (!config) return;
  const active = isActive(config);
  const remaining = passRemainingSeconds(config);
  const status = els.status;

  status.classList.remove('on', 'pass');
  if (!config.enabled) {
    status.textContent = '已暂停 · 白名单保留，页面暂时恢复原样';
  } else if (remaining > 0) {
    status.classList.add('pass');
    status.textContent = `临时放行中 · 还剩 ${Math.ceil(remaining / 60)} 分钟`;
  } else if (!active) {
    status.textContent = '已暂停';
  } else {
    status.classList.add('on');
    const total = config.videos.length + config.uploaders.length;
    status.textContent =
      total === 0
        ? '生效中 · 白名单为空，首页会完全清空'
        : `生效中 · 白名单 ${config.videos.length} 个视频 / ${config.uploaders.length} 个 UP 主`;
  }

  els.passBanner.hidden = remaining <= 0;
  if (remaining > 0) {
    els.passText.textContent = `已临时放行，${Math.ceil(remaining / 60)} 分钟后自动恢复专注模式`;
  }
  els.passBtn.textContent = remaining > 0 ? '恢复' : '放行';
}

/* ------------------------------------------------------------------ */
/* 视频列表                                                             */
/* ------------------------------------------------------------------ */

function renderVideos() {
  if (!config) return;
  const videos = config.videos;
  els.countVideos.textContent = String(videos.length);
  els.countUploaders.textContent = String(config.uploaders.length);

  if (videos.length === 0) {
    els.videoList.innerHTML = '';
    els.videoEmpty.hidden = false;
    return;
  }
  els.videoEmpty.hidden = true;

  els.videoList.innerHTML = videos
    .map((video) => {
      const cover = video.cover
        ? `<img src="${escapeHtml(video.cover)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
        : '<div class="ph">▶</div>';
      const duration = formatDuration(video.duration);
      const upLabel = video.upName ? escapeHtml(video.upName) : '未知 UP 主';
      const upAction =
        video.upMid > 0
          ? `<button type="button" data-action="allow-up" data-mid="${video.upMid}">放行此 UP 主</button>`
          : '';
      return `
        <div class="video-item" data-key="${escapeHtml(video.bvid || `av${video.aid}`)}">
          <div class="video-cover">${cover}${duration ? `<span class="dur">${duration}</span>` : ''}</div>
          <div class="video-meta">
            <div class="video-title" title="${escapeHtml(video.title)}">${escapeHtml(video.title || video.bvid || `av${video.aid}`)}</div>
            <div class="video-sub">
              <span>${upLabel}</span>
              <span>·</span>
              <span>${escapeHtml(video.bvid || `av${video.aid}`)}</span>
              ${upAction}
            </div>
          </div>
          <div class="item-actions">
            <button type="button" class="mini-btn" data-action="open" data-bvid="${escapeHtml(video.bvid || '')}">打开</button>
            <button type="button" class="mini-btn danger" data-action="remove" data-bvid="${escapeHtml(video.bvid || '')}" data-aid="${video.aid || 0}">移除</button>
          </div>
        </div>
      `;
    })
    .join('');
}

/* ------------------------------------------------------------------ */
/* UP 主列表                                                            */
/* ------------------------------------------------------------------ */

function renderUploaders() {
  if (!config) return;
  const uploaders = config.uploaders;
  els.countUploaders.textContent = String(uploaders.length);
  if (uploaders.length === 0) {
    els.uploaderList.innerHTML = '';
    els.uploaderEmpty.hidden = false;
    return;
  }
  els.uploaderEmpty.hidden = true;
  els.uploaderList.innerHTML = uploaders
    .map((up) => {
      const avatar = up.face
        ? `<img src="${escapeHtml(up.face)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
        : escapeHtml((up.name || '?').slice(0, 1));
      return `
        <div class="uploader-item" data-mid="${up.mid}">
          <div class="uploader-avatar">${avatar}</div>
          <div class="uploader-name">
            ${escapeHtml(up.name || '未知 UP 主')}
            <small>mid ${up.mid} · 该 UP 主的全部视频都放行</small>
          </div>
          <button type="button" class="mini-btn danger" data-action="remove-up" data-mid="${up.mid}">移除</button>
        </div>
      `;
    })
    .join('');
}

/* ------------------------------------------------------------------ */
/* 屏蔽项                                                               */
/* ------------------------------------------------------------------ */

function renderSettings() {
  if (!config) return;
  els.settingsList.innerHTML = SETTING_META.map((meta) => {
    const checked = Boolean(config.settings?.[meta.key] ?? DEFAULT_SETTINGS[meta.key]);
    return `
      <label class="setting">
        <span class="setting-text">
          <span class="setting-name">${meta.name}</span>
          <span class="setting-desc">${meta.desc}</span>
        </span>
        <span class="switch">
          <input type="checkbox" data-setting="${meta.key}" ${checked ? 'checked' : ''}>
          <span></span>
        </span>
      </label>
    `;
  }).join('');
}

/* ------------------------------------------------------------------ */
/* 当前标签页                                                           */
/* ------------------------------------------------------------------ */

async function loadCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tab || null;
  } catch {
    currentTab = null;
  }
  updateAddCurrent();
}

function currentVideoRef() {
  if (!currentTab?.url) return null;
  if (!/^https?:\/\/([a-z0-9-]+\.)?bilibili\.com\//i.test(currentTab.url)) return null;
  return parseVideoRef(currentTab.url);
}

function updateAddCurrent() {
  const ref = currentVideoRef();
  els.addCurrent.disabled = !ref;
  els.addCurrent.title = ref
    ? `把「${currentTab.title || ref.bvid || ref.aid}」加入白名单`
    : '先打开一个 B 站视频页';
}

/* ------------------------------------------------------------------ */
/* 事件                                                                 */
/* ------------------------------------------------------------------ */

els.videoList.addEventListener('click', async (event) => {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const action = button.dataset.action;

  if (action === 'open') {
    const bvid = button.dataset.bvid;
    if (bvid) chrome.tabs.create({ url: `https://www.bilibili.com/video/${bvid}` });
    return;
  }

  if (action === 'remove') {
    const result = await send({
      type: 'removeVideo',
      video: { bvid: button.dataset.bvid || '', aid: Number(button.dataset.aid || 0) },
    });
    if (result?.ok) {
      toast('已移除');
      applyConfig(result.config);
    }
    return;
  }

  if (action === 'allow-up') {
    const mid = Number(button.dataset.mid);
    const result = await send({ type: 'addUploader', uploader: { mid } });
    if (result?.ok) {
      toast('已放行这个 UP 主的全部视频');
      applyConfig(result.config);
    } else {
      toast('放行失败：' + (result?.error || '未知错误'));
    }
  }
});

els.uploaderList.addEventListener('click', async (event) => {
  const button = event.target.closest('button[data-action="remove-up"]');
  if (!button) return;
  const result = await send({ type: 'removeUploader', mid: Number(button.dataset.mid) });
  if (result?.ok) {
    toast('已移除该 UP 主');
    applyConfig(result.config);
  }
});

els.addCurrent.addEventListener('click', async () => {
  const ref = currentVideoRef();
  if (!ref) {
    toast('先打开一个 B 站视频页');
    return;
  }
  els.addCurrent.disabled = true;
  const result = await send({ type: 'addFromUrl', url: currentTab.url });
  els.addCurrent.disabled = false;
  if (!result?.ok) {
    toast('添加失败：' + (result?.error || '未知错误'));
    return;
  }
  toast(result.action === 'exists' ? '这个视频已经在白名单里' : '已加入白名单');
  applyConfig(result.config);
});

async function addFromInput() {
  const text = els.videoInput.value.trim();
  if (!text) {
    toast('先粘贴一个视频链接或 BV 号');
    return;
  }
  const result = await send({ type: 'addFromUrl', url: text });
  if (!result?.ok) {
    toast('添加失败：' + (result?.error || '未知错误'));
    return;
  }
  els.videoInput.value = '';
  toast(result.action === 'exists' ? '这个视频已经在白名单里' : '已加入白名单');
  applyConfig(result.config);
}

els.addInput.addEventListener('click', addFromInput);
els.videoInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') addFromInput();
});

async function addUploaderFromInput() {
  const raw = els.midInput.value.trim();
  const mid = Number((raw.match(/(\d{1,12})/) || [])[1]);
  if (!mid) {
    toast('填 UP 主的 mid，或者直接贴他的空间链接');
    return;
  }
  const result = await send({ type: 'addUploader', uploader: { mid } });
  if (!result?.ok) {
    toast('添加失败：' + (result?.error || '未知错误'));
    return;
  }
  els.midInput.value = '';
  toast('已放行该 UP 主');
  applyConfig(result.config);
}

els.addMid.addEventListener('click', addUploaderFromInput);
els.midInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') addUploaderFromInput();
});

els.settingsList.addEventListener('change', async (event) => {
  const input = event.target.closest('input[data-setting]');
  if (!input) return;
  const result = await send({ type: 'setSettings', settings: { [input.dataset.setting]: input.checked } });
  if (result?.ok) {
    config = result.config;
    renderStatus();
  }
});

els.passBtn.addEventListener('click', async () => {
  const remaining = passRemainingSeconds(config);
  const result = await send({ type: 'setPass', minutes: remaining > 0 ? 0 : 30 });
  if (result?.ok) {
    applyConfig(result.config);
    toast(remaining > 0 ? '已恢复专注模式' : '已放行 30 分钟，到点自动恢复');
  }
});

els.passCancel.addEventListener('click', async () => {
  const result = await send({ type: 'setPass', minutes: 0 });
  if (result?.ok) applyConfig(result.config);
});

/* 长按「放行」也可以选时长 —— 用 dblclick 简化 */
els.passBtn.addEventListener('contextmenu', async (event) => {
  event.preventDefault();
  const result = await send({ type: 'setPass', minutes: 60 });
  if (result?.ok) {
    applyConfig(result.config);
    toast('已放行 60 分钟');
  }
});

els.exportBtn.addEventListener('click', async () => {
  const state = config || (await readConfig());
  const payload = {
    app: 'bilibili-focus',
    version: 1,
    exportedAt: new Date().toISOString(),
    videos: state.videos,
    uploaders: state.uploaders,
    settings: state.settings,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `bilibili-focus-${new Date().toISOString().slice(0, 10)}.json`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  toast('已导出白名单');
});

els.importBtn.addEventListener('click', () => els.importFile.click());

els.importFile.addEventListener('change', async () => {
  const file = els.importFile.files?.[0];
  if (!file) return;
  try {
    const payload = JSON.parse(await file.text());
    const result = await send({ type: 'importConfig', payload });
    if (result?.ok) {
      applyConfig(result.config);
      toast('已导入');
    } else {
      toast('导入失败：' + (result?.error || '未知错误'));
    }
  } catch {
    toast('这个文件不是有效的白名单 JSON');
  } finally {
    els.importFile.value = '';
  }
});

els.openFull.addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup/popup.html?view=full') });
});

function activateTab(name) {
  document.querySelectorAll('.tab').forEach((node) => {
    node.classList.toggle('is-active', node.dataset.tab === name);
  });
  document.querySelectorAll('.tab-panel').forEach((panel) => {
    panel.classList.toggle('is-active', panel.id === `tab-${name}`);
  });
}

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => activateTab(tab.dataset.tab));
});

// 支持 #settings 直达（也方便截图和调试）
if (params.get('tab')) activateTab(params.get('tab'));
else if (location.hash) activateTab(location.hash.replace('#', ''));

/* ------------------------------------------------------------------ */
/* 启动                                                                 */
/* ------------------------------------------------------------------ */

(async function init() {
  if (window.__DEMO__) {
    config = window.__demoReadConfig();
  } else {
    try {
      config = await readConfig();
    } catch (error) {
      config = window.__demoReadConfig ? window.__demoReadConfig() : null;
    }
  }
  if (!config) {
    els.status.textContent = '读取配置失败，请重新打开';
    return;
  }
  applyConfig(config);
  await loadCurrentTab();

  onConfigChanged((next) => {
    config = next;
    applyConfig(next);
  });

  chrome.tabs.onActivated?.addListener(() => loadCurrentTab());
  chrome.tabs.onUpdated?.addListener((tabId, changeInfo, tab) => {
    if (currentTab?.id === tabId && changeInfo.url) {
      currentTab = tab;
      updateAddCurrent();
    }
  });

  // 临时放行的倒计时每秒刷一次
  setInterval(() => {
    if (config && config.pausedUntil > Date.now()) renderStatus();
    else if (config && config.pausedUntil && config.pausedUntil < Date.now()) {
      config.pausedUntil = 0;
      renderStatus();
    }
  }, 1000);
})();

/* 供调试 */
window.__bfPopup = { get config() { return config; } };
